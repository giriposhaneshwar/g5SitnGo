(function () {
    'use strict';

    angular
        .module('app')
        .controller('SitNGoTest.IndexController', ["$scope",  function ($scope) {

    }])
})();