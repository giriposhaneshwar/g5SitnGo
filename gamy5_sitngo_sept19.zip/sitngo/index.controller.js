(function () {
    'use strict';

    angular
            .module('app')
            .controller('SitNGo.IndexController', ["$scope", "$interval", "$compile", "$pbService", "$timeout", "$window", function ($scope, $interval, $compile, $pbService, $timeout, $window) {
                    $scope.code = 'Demonstrate two-way da binding';

                    var message;
                    var questionText;
                    $scope.message = message;
                    $scope.timeToAnswer = 4000;
                    $window.timeToAnswer = $scope.timeToAnswer;

                    var arr = [];

                    arr[1] = '{"GameId":2276,"TimeToServeQuestion":10,"PoolAmount":10,"GameTableId":1,"Players":[{"PlayerId":618,"TableId":1,"UserId":"cd50445e-8ebc-4dfa-9d01-ef31ee9690aa","ProfileImage":"https://g5r.blob.core.windows.net/imgs/65c7cc2c-2867-474d-bfe6-7e03f864264a/profilepic.jpg","DisplayName":"sreekanth@mezzlabs.com","Status":3,"UserWallet":{"FreeCoins":500894,"Amount":50,"UserId":"cd50445e-8ebc-4dfa-9d01-ef31ee9690aa"}},{"PlayerId":619,"TableId":1,"UserId":"bc9862f9-aef0-4daa-81af-8a72d6d4e0bb","ProfileImage":"https://g5r.blob.core.windows.net/imgs/65c7cc2c-2867-474d-bfe6-7e03f864264a/profilepic.jpg","DisplayName":"spayyavula@gmail.com","Status":3,"UserWallet":{"FreeCoins":500894,"Amount":50,"UserId":"bc9862f9-aef0-4daa-81af-8a72d6d4e0bb"}}],"Message":" Game Started."}';

                    arr[2] = '{"GameId":2276,"QuestionId":"a8c6e168-7e40-461b-b21f-21c085e6b84f","Description":"The area bounded by the lines y= 2 +x,y= 2x??and??x= 2 is","TimetoAnswer":30,"Choices":[{"ChoiceId":"0e9dee8f-bbf0-4430-b447-98847fc276af","Title":"3"},{"ChoiceId":"3d49b90e-aa02-407b-abe8-bdc06c46bb8b","Title":"16"},{"ChoiceId":"2ab20994-e305-444a-8a6b-c1e7d3f5912b","Title":"4"},{"ChoiceId":"c05ede50-20c5-4e5c-a538-fdaac39b8381","Title":"8"}],"GameTableId":0,"Players":[{"UserId":"cd50445e-8ebc-4dfa-9d01-ef31ee9690aa","Status":3},{"UserId":"bc9862f9-aef0-4daa-81af-8a72d6d4e0bb","Status":3}],"Message":null}';

                    arr[3] = '{"GameId":2508,"AnswerId":"9815cc84-236b-4a0d-a8e3-50a4188a077a","GameTableId":9,"Players":[{"UserId":"0e73aede-4ef8-4460-8cdb-037b52c568c1","Status":3},{"UserId":"7a67f398-140b-4b85-b22b-a858206d81a2","Status":3}],"Message":null}';

                    arr[4] = '[{"GameTableId":9,"GameId":2508,"userId":"0e73aede-4ef8-4460-8cdb-037b52c568c1","DisplayName":null,"timetakeninseconds":0,"Earned":4.75,"IsCorrectAnswer":false},{"GameTableId":9,"GameId":2508,"userId":"7a67f398-140b-4b85-b22b-a858206d81a2","DisplayName":null,"timetakeninseconds":0,"Earned":4.75,"IsCorrectAnswer":false}]';

                    arr[5] = "Game will Start in few seconds.";

                    var i = 0;





                    var game = $interval(function () {
                        simulate(i);
                        i += 1;
                    }, 5000);


                    function simulate(i) {

                        switch (i) {

                            case 1: //startGame                   
                                $scope.message = arr[1];
                                break;
                                /*
                                 case 2: //serveQuestion
                                 var question = getQuestion(queue[4]);
                                 questionText = question.question;
                                 $localStorage.question = questionText;
                                 $scope.question = $localStorage.question;
                                 $scope.message =  queue[4];
                                 break;
                                 case 3://serveAnswer
                                 console.log(queue[5]);
                                 var question = getQuestion(queue[4]);
                                 questionText = question.question;
                                 $scope.message =  queue[5];
                                 $scope.question = questionText;
                                 break;
                                 case 4://displayResults
                                 var question = getQuestion(queue[4]);
                                 questionText = question.question;
                                 $scope.message = queue[6];
                                 $scope.question = questionText;
                                 break;
                                 case 5://reset Game
                                 $scope.message = queue[7];
                                 clearTimer();
                                 */
                        }
                    }

                    function clearTimer() {
                        $interval.cancel(game);
                    }


                }])
            .directive('opponentsData', function ($parse) {
                var directiveDefinitionObject = {
                    restrict: 'EA',
                    link: function (scope, el, attr) {
                        var exp = $parse(attr.opponentsData);
                        scope.$watchCollection(exp, function (newVal, oldVal) {
                            var players = getPlayerPositions(newVal);
                            scope.players = players;


                        })

                        function getPlayerPositions(newVal) {
                            var positions = [{}];

                            return [
                                {"left": 0, "top": 110, "width": 50, "height": 50},
                                {"left": 240, "top": 63, "width": 50, "height": 50},
                                {"left": 480, "top": 50, "width": 50, "height": 50},
                                {"left": 720, "top": 63, "width": 50, "height": 50},
                                {"left": 950, "top": 110, "width": 50, "height": 50}
                            ]
                        }
                    },
                    templateUrl: 'directives/opponents.html'
                }
                return directiveDefinitionObject;

            })
            .directive('questionData', function ($parse, $timeout) {
                var directiveDefinitionObject = {
                    restrict: 'EA',
                    compile: function (element, attributes, transclude) {

                    },
                    templateUrl: 'directives/questions.html'
                }
                return directiveDefinitionObject;

            })
            .directive('selfData', function ($parse) {
                var directiveDefinitionObject = {
                    restrict: 'EA',
                    link: function (scope, el, attr) {
                        var exp = $parse(attr.selfData);
                        scope.$watchCollection(exp, function (newVal, oldVal) {
                            var players = {"left": 480, "top": 10, "width": 50, "height": 50};
                            scope.self = players;

                        })
                    },
                    templateUrl: 'directives/self.html'
                }
                return directiveDefinitionObject;

            })
//            .directive('newWindow', ['$window', '$compile', function ($window, $compile) {
//                    return {
//                        restrict: 'EA',
//                        link: function ($scope, $element, attr) {
//                            $element.on('$destroy', function () {
//                                $scope.window.close();
//                            });
//
//                            var svgPath = angular.element(document.querySelector('arc-path'));
//
//                            var path = new ProgressBar.Path(svgPath, {
//                                duration: 3200,
//                                easing: 'easeIn'
//                            });
//
//                            path.animate(1, {
//                                duration: 3200
//                            }, function () {
//                                console.log('Animation has finished');
//                            });
//
//
//                        },
//                        controller: function ($scope, $element) {
//                            $scope.window = $window.open('', '_blank', 'scrollbars=0,fullscreen=no,toolbar=no,status=no,menubar=no,scrollbars=no,resizable=false,width=1000,height=800');
////                            angular.element($scope.window.document.body.style.background = 'lightgrey');
//                            $scope.window["takingD"] = function () {
//                                alert(1);
//                            }
//                            angular.element($scope.window.document.body).append($compile($element.contents())($scope));
//                        },
//                        templateUrl: 'directives/window.html'
//                    }
//                }])

})()