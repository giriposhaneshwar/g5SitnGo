(function () {
    'use strict';

    angular
        .module('app')
        .controller('Games.IndexController', ["$scope", 'serviceCall', '$http',  
                                function ($scope, serviceCall, $http) {
            console.log('Games Controller');                            

    }])
})();