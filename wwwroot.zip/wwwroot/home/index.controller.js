﻿(function () {
    'use strict';

    angular
            .module('app')
            .controller('Home.IndexController', Controller);

    function Controller($scope, $rootScope, $location, $timeout, $window, $cookies, $q, $http, $interval, $localStorage, localStorageService, AuthenticationService, commonService, serviceCall, authService, ngAuthSettings) {
        var vm = this;

        var userData = localStorageService.get('userInfo');

        $rootScope.playMode = commonService.playModeDefault;

        $scope.initController = function () {
            $scope.loggedUser = $cookies.get('currentUserName');
            $scope.ReferralId = userData.Referal_Code;
            /* FB.init({
             appId: '1099750626761695',
             cookie: true,
             status: true,
             xfbml: true
             });*/
            if (userData.userInfo.displayName == (null || undefined) || userData.userInfo.displayName == '') {
                $window.location.href = "#/editprofile"
            }

        };
        $scope.initController();

        $scope.logoutUser = function () {
            serviceCall.logoutUser(function (res) {
                console.log("Logging user out", res);
                if (res.status === "success") {
                    $timeout(function () {
                        $location.path("#/login");
                    }, 3000);
                } else {
                    alert("Could no loggout");
                }
            });
        };
        $scope.newService = function () {
            serviceCall.getValues(function (response) {
                console.log("REsponse for Get Values", response);
            });
        };


        $scope.facebookShare = function ()
        {
            FB.ui({method: 'apprequests',
                message: 'YOUR_MESSAGE_HERE'
            }, function (response) {
                console.log(response);
            });



        }
        $scope.toggleFreePaid = function (evt) {
            evt.preventDefault();
            $rootScope.playMode = ($rootScope.playMode === "free") ? "paid" : "free";

//            commonService.log("LocalStorage for Authorization Data ::: 42", localStorageService.get('authorizationData'));
            if ($rootScope.playMode == "paid") {
                if (!userData.hasGamy5Account) {

                    var str = userData.userInfo;

                    //var isEmail = commonService.emailPattern.test(str);
                    $scope.toggleSetPasswordTab(2, str.Email, userData.IsEmailVerified);

                    if (str.Email == null)
                    {
                        // set password
                        $scope.isEmailDisable = false;
                    } else if (!userData.IsEmailVerified)
                    {
                        $scope.isEmailDisable = false;
                    } else {
                        // register
                        $scope.isEmailDisable = true;
                    }

//                    $scope.registerGamy5User(authData, userData);
                }
            } else {
                commonService.log("Toggle FreePaid at Home Controller ::::49 : ", $rootScope.playMode);
            }
        }

        $scope.createGamy5User = function (evt, data) {
            commonService.log("Create Gamy5 User at Home Page :::96", data);
            var sendData = {
                "userName": data.Email,
                "password": data.Password,
                "rememberMe": true
            };
            serviceCall.createGamy5UserService(sendData, function (response) {
                commonService.log("Response From Gamy5 Create Account ::::76", response);
                if (response.errorCode === 200) {
                    $scope.err = true;
                    $scope.errStatus = true;
                    $scope.statusMessage = response.result;

                    var userData = localStorageService.get('userInfo');
                    console.log("AuthData", userData.IsEmailVerified);

                    localStorageService.set('_g5_ud', btoa(JSON.stringify(data)));
//                                        localStorageService.set('userInfo', userData);
                    if (!userData.IsEmailVerified)
                    {
                        $window.location.href = "#/activate";
                    } else {
                        $timeout(function () {
//                        history.back();
                            $window.location.href = "#/active";
                        }, commonService.redirectTime);
                    }
                } else {

                    $scope.err = true;
                    $scope.errStatus = false;
                    $scope.statusMessage = response.errorMessage;
                }
            })


        }

        $scope.setPassword = {};
        $scope.toggleSetPasswordTab = function (val, data, isEmail) {
            console.log("Set Tab", val, data);
            $scope.isEmailDisable = false;

            if (data != undefined && data != null)
            {
                if (!isEmail)
                {
                    $scope.setPassword.Email = data;
                    $scope.isEmailDisable = false;
                } else {
                    $scope.setPassword.Email = data;
                    $scope.isEmailDisable = true;
                }
            }

            if (val === 1) {
                $scope.setPassword.Email = '';
                $scope.setPassword.Password = '';
                $scope.statusMessage = '';
                $scope.setPasswordFormShow = "homePage";
                $rootScope.playMode = "free";
            } else if (val === 2) {
                $scope.nonGamy5UserHeading = "Create Gamy5 User";
                $scope.setPasswordFormShow = "createGamy5User";

            }
        }
        $scope.toggleSetPasswordTab(1);




    }

})();