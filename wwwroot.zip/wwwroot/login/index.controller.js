﻿(function () {
    'use strict';
    angular
            .module('app')
            .controller('Login.IndexController', Controller);
    function Controller($scope, $rootScope, $location, $window, $localStorage, $q, $http, $cookies, $timeout, $interval, AuthenticationService, commonService, serviceCall, authService, ngAuthSettings, localStorageService) {
        var vm = this;
        /* Defaults */
        $scope.statusMessage = '';
        $scope.loading = false;
        $scope.activateTabPanel = false;

        $scope.init = function () {
            // check if the user is logged in or not
            $scope.inputType = "password";
            var userinfo = localStorageService.get('userInfo');
            if ($cookies.get('currentUser') != undefined || "" || null) {
                if (userinfo.userInfo.displayName == (null || undefined) || userinfo.userInfo.displayName == '') {
                    $window.location.href = "#/editprofile"
                } else {
                    $window.location.href = commonService.landingPage
                }
                ;
            }
        };
        $scope.init();
        $scope.showPassword = function () {

            if ($scope.inputType == "password")
                $scope.inputType = "text";
            else
                $scope.inputType = "password";

        }
        $scope.getProfileData = function () {

            commonService.log("User Profile is ", $scope.userData);
            var tStamp = new Date();

            serviceCall.getProfileService(function (response) {
                commonService.log("Response from Profile", response);
                if (!response.isError) {
                    $scope.profile = response.result;

                    if ($scope.profile.countryId == (null || undefined)) {

                        $scope.profile.countryId = 101;
                    }
                    angular.forEach($scope.CountryArray, function (country) {
                        if (country.id == $scope.profile.countryId) {
                            $scope.CountryName = country.name;

                        }
                    });
                    $scope.getStates();
                    if (response.result.profileImageUrl != null) {

                        $scope.profileImage = response.result.profileImageUrl + "?v=" + tStamp.getTime();
                    }
                    if (response.result.panImageUrl != null) {
                        $scope.panImage = response.result.panImageUrl + "?v=" + tStamp.getTime();
                    }
                    if (response.result.gender != null) {

                        if (response.result.gender == 'male') {
                            $scope.maleGender = false;
                            $scope.femaleGender = true;
                        } else {
                            $scope.maleGender = true;
                            $scope.femaleGender = false;
                        }

                    }
                    $scope.profile.dateOfBirth = commonService.dateToLocal(response.result.dateOfBirth);
                }
            });

        };
        $scope.userLogin = function (evt, data) {
            evt.preventDefault();
            var obj = {username: data.username, password: data.password, RememberMe: true};


            $scope.loading = true;
            serviceCall.loginUser(obj, function (res) {
                commonService.log("Login Response 26:::", res);
                if (res.errorCode === 200) {
                    serviceCall.getProfileService(function (response) {
                        if (!response.isError) {
                            $scope.profile = response.result;

                            if (response.result.profileImageUrl != null) {
                                $scope.profile.profileImage = response.result.profileImageUrl + "?v=" + tStamp.getTime();
                            }
                            if (response.result.panImageUrl != null) {
                                $scope.profile.panImage = response.result.panImageUrl + "?v=" + tStamp.getTime();
                            }
                            $scope.profile.dateOfBirth = commonService.dateToLocal(response.result.dateOfBirth);
                            res.userInfo = $scope.profile;
                            localStorageService.set('userInfo', res.result);
                        }
                    });
//                    delete $localStorage.appData;
                    $timeout(function () {
                        $scope.loading = false;
                        $window.location.href = commonService.landingPage;
                    }, commonService.redirectTime);
                } else if (res.errorCode === 412) {
                    // user is not activated and will redirect to activation screen
                    $scope.loading = false;
                    $scope.errStatus = true;
                    $scope.err = true;
                    $scope.statusMessage = res.errorMessage;
                    var obj = {};
                    obj['Email'] = data.username;
                    obj['Password'] = data.password;
                    localStorageService.set('_g5_ud', btoa(JSON.stringify(obj)));

                    $timeout(function () {
                        $window.location.href = "#/activate";
                    }, commonService.redirectTime);
                } else {
                    $scope.loading = false;
                    $scope.errStatus = true;
                    $scope.err = true;
                    $scope.statusMessage = res.errorMessage;
                }

                $timeout(function () {
                    $scope.err = false;
                }, 8000);

            });





        };

        $scope.authExternalProvider = function (provider) {
            var loc = $window.location.href;
            //loc=loc.replace("g5web/",'');
            var url = loc.split("#");

            var redirectUri = url[0] + 'authComplete.html';
            var externalProviderUrl = ngAuthSettings.apiServiceBaseUri + "api/Account/ExternalLogin?provider=" + provider
                    + "&response_type=token&client_id=" + ngAuthSettings.clientId
                    + "&redirect_uri=" + redirectUri;
            //            alert(externalProviderUrl);
            window.$windowScope = $scope;
            var oauthWindow = window.open(externalProviderUrl, "Authenticate_Account", "locaiton=0,status=0, width=600, height=750");
        };
        // check for fragment every 100ms
        var _interval = $interval(_checkForFragment, 100);
        function _checkForFragment() {
            var fragment = localStorage.getItem("auth_fragment");

            if (fragment !== null) {
                console.log("Fragment", fragment);
            }
            if (fragment && (fragment = JSON.parse(fragment))) {

                // clear the fragment from the storage
                localStorage.removeItem("auth_fragment");
                // continue as usual
                $scope.authCompletedCB(fragment);                 // stop looking for fragmet
                _clearInterval();
            }
        }

        function _clearInterval() {
            $interval.cancel(_interval);
        }

        $scope.$on("$destroy", function () {
            // clear the interval when $scope is destroyed
            _clearInterval();
        });
        $scope.authCompletedCB = function (fragment) {
            console.log("Fragment ", fragment);
            if (fragment.haslocalaccount == 'False') {

                authService.logOut();
                authService.externalAuthData = {
                    provider: fragment.provider,
                    userName: fragment.external_user_name,
                    externalAccessToken: fragment.external_access_token
                };
                $window.location.href = '#/login';
            } else {
                /*
                 Obtain access token and redirect to orders
                 */
                var externalData = {provider: fragment.provider, externalAccessToken: fragment.external_access_token};
                authService.obtainAccessToken(externalData).then(function (response) {


                    $window.location.href = commonService.landingPage;

                }).catch(function (err) {
                    console.log("Obtain Local Access Failed", err);
                    if (err != null) {
                        $scope.message = err.error_description;
                    }
                });

            }
            ;
//            });
        }
        $scope.toggleActivationTab = function (tab) {
            $scope.activation = false;
            if (tab === 1) {
                $scope.activation = false;
            } else if (tab === 2) {
                $scope.activation = true;
            }
            commonService.log("toggleActivationTab", tab, $scope.activation, "logFalse");
        };
        $scope.activateUser = function (evt, data) {
            evt.preventDefault();
            data.Email = $scope.login.username;
            data.Password = $scope.login.password;

            commonService.log("ActivationUser from Login :::137", data);

            serviceCall.verifyUserAndLoginService(data, function (response) {
                commonService.log("Email Activation Log on 91", response);
                if (response.errorCode === 200) {
                    $scope.loading = false;
                    $scope.errStatus = true;
                    $scope.err = true;
                    $scope.statusMessage = response.errorMessage;
                    $window.location.href = commonService.landingPage;
                } else {
                    $scope.loading = false;
                    $scope.errStatus = false;
                    $scope.err = true;
                    $scope.statusMessage = response.errorMessage;
                }
            });
        };
        $scope.resedActivationCode = function () {
            serviceCall.resendActicationCodeService($scope.login.username, function (response) {
                if (response.errorCode === 200) {
                    $scope.err = true;
                    $scope.errStatus = true;
                    $scope.statusMessage = response.result;
                } else {
                    $scope.err = true;
                    $scope.errStatus = false;
                    $scope.statusMessage = response.result;
                }
            });
        };
    }

})();
/*
 // Login Service call
 http://192.168.0.47/token
 */ 