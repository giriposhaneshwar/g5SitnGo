﻿(function () {
    'use strict';

    angular
            .module('app')
            .controller('PasswordReset.IndexController', Controller);

    function Controller($scope, $rootScope, $location, $window, $cookies, $q, $http, $timeout, $localStorage, AuthenticationService, localStorageService, commonService, serviceCall) {
        var vm = this;

        $scope.loading = false;
        $scope.emailPattern = commonService.emailPattern;
        $scope.postData = {};
        $scope.initController = function () {

        };
        $scope.initController();


        var url = $window.location.hash;
        $scope.getParams = function (url) {
            $scope.urlParams = {};
            $scope.urlParams.emailAddress = $location.search().email;
            $scope.urlParams.code = $location.search().code;
            $scope.urlParams.userId = $location.search().userId;

        };
        $scope.getParams(url);


// Must have lines in all controller
        $scope.init = function () {
            $scope.checkUserLogin();
            if ($rootScope.userCheckLogged !== undefined) {
                $scope.playZones();
                $scope.setDefaultSubject($scope.params);
            }
        }

        $scope.checkUserLogin = function () {
            $rootScope.userCheckLogged = $cookies.get('currentUser');
            console.log("Check Login", $rootScope.userCheckLogged);
            if ($rootScope.userCheckLogged === undefined) {
                $window.location.href = "#/login";
            }
        }

        //////////////////////


        $scope.inputType = "password";
        $scope.resetPassword = function (evt, data) {
            evt.preventDefault();

            $scope.userData = JSON.parse(atob(localStorageService.get('_g5_ud')));
            if ($scope.userData.email != (null || undefined)) {
                $scope.postData.email = $scope.userData.email;
            }
            var obj = {
                "email": $scope.postData.email,
                "password": data.password,
                "confirmPassword": data.password,
                "code": data.code
            };

            commonService.log("Reset Password Before Send Object 39:::", obj);
            serviceCall.resetPasswordService(obj, function (res) {
                $scope.resetResponse = "";
                if (res.errorCode == 200) {


                    $('#resetGreat').modal({backdrop: 'static', keyboard: true, show: true});
                } else {
                    $scope.resetResponse = res.errorMessage;
                    $scope.resetStatus = false;
                }
                console.log("Response From Server", res);
            });

        };


        $scope.changePassword = function (evt, data) {
            evt.preventDefault();
            var obj = {
                OldPassword: data.oldpassword,
                NewPassword: data.password,
                ConfirmPassword: data.password
            };
//                Email: data.email,
            $scope.handleResponse = {};

            serviceCall.changePassword(obj, function (res) {
                console.log("Change Password ", res);
                if (!res.isError) {

                    /* serviceCall.logoutUser(function (response) {
                     if (response.status === 'success') {
                     $timeout(function () {
                     //                                alert("redirect");
                     $window.location.href = "#/login";
                     }, 3000);
                     }
                     });*/
                    $("#profileGreat").modal('show');
                    $timeout(function () {
//                                alert("redirect");
                        $('body').removeClass().removeAttr('style');
                        $('.modal-backdrop').remove();
                        $window.location.href = commonService.landingPage;
                    }, 3000);
                } else {
                    $scope.handleResponse.message = res.errorMessage;
                    $scope.handleResponse.status = false;
                }
            });


        };
        $scope.goToPreviousPage = function () {
            window.history.back();
        };



        $scope.varificationForgotPassword = false;

        $scope.sendForgotPassword = function (evt, data) {
            evt.preventDefault();
            localStorageService.set('_g5_ud', btoa(JSON.stringify(data)));
            serviceCall.forgotPassword(data.email, function (response) {
                console.log("Response Forgot Password ", response);
                if (response.errorCode === 200) {
                    $scope.responseState = true;
                    $scope.showError = true;
                    $scope.forgotPasswordResponse = response.result;

                    $timeout(function () {
                        $scope.showError = false;
                        $window.location.href = "#/resetPassword";
                        $scope.varificationForgotPassword = true;

                    }, 2000);
                } else {
                    $scope.responseState = false;
                    $scope.showError = true;
                    $scope.forgotPasswordResponse = response.errorMessage;
                }

                $timeout(function () {
                    $scope.showError = false;

                }, 8000);
            });
        };
        $scope.resendForgotPassword = function (evt) {
            evt.preventDefault();
            $scope.postData.code = "";
            $scope.resetResponse = '';
            $scope.userData = JSON.parse(atob(localStorageService.get('_g5_ud')));
            if ($scope.userData.email != (null || undefined)) {
                $scope.postData.email = $scope.userData.email;
            }
            serviceCall.resendForgotPasswordService(data, function (response) {
                if (response.errorCode === 200) {
                    $scope.responseState1 = true;
                    $scope.showError1 = true;
                    $scope.resetforgotPasswordResponse = response.result;
                } else {
                    $scope.responseState1 = false;
                    $scope.showError1 = true;
                    $scope.resetforgotPasswordResponse = response.errorMessage;
                }

                $timeout(function () {
                    $scope.showError1 = false;
                }, 8000);
            });
        };
        $scope.continuePage = function () {
            $('body').removeClass().removeAttr('style');
            $('.modal-backdrop').remove();

            $window.location.href = '#/login';
        }
        /*  $scope.verifyForgotPassword = function (evt, data) {
         evt.preventDefault();
         $rootScope.postData['code'] = data.code;
         var obj = {Email: $scope.postData.email, Code: data.code};
         console.log("Verification Before Send", obj);
         serviceCall.verifyUserService(obj, function (response) {
         if (response.errorCode === 200) {
         $scope.responseState = true;
         $scope.showError = true;
         $scope.forgotPasswordResponse = response.errorMessage;
         $window.location.href = "#/passwordreset";
         } else {
         $scope.responseState = false;
         $scope.showError = true;
         $scope.forgotPasswordResponse = response.errorMessage;
         }
         commonService.log("Verification forgot Password From Service 135:::", response);
         });
         };*/


    }

})();
