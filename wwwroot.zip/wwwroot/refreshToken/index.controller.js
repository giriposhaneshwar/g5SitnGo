﻿(function () {
    'use strict';
    angular
            .module('app')
            .controller('Login.IndexController', Controller);
    function Controller($scope, $rootScope, $location, $window, $localStorage, $q, $http, $cookies, $timeout, $interval, AuthenticationService, commonService, serviceCall, authService, ngAuthSettings, localStorageService) {
        
    }

})();
/*
 // Login Service call
 http://192.168.0.47/token
 */ 