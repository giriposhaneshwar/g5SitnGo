(function () {
    'use strict';
    angular
            .module('app')
            .controller('Dashboard.IndexController', Controller);
    function Controller($scope, $rootScope, $location, $window, $localStorage, $http, $cookies, $timeout, $interval, AuthenticationService, commonService, serviceCall, authService, ngAuthSettings, localStorageService) {


        var vm = this;
        var data = "";
        var popularGames;
        var trendingGames;
        var subjectsList;
        $('#myCarousel').carousel({
            interval: false
        });
        $('#myCarousel .item').each(function () {
            var next = $(this).next();
            if (!next.length) {
                next = $(this).siblings(':first');
            }
            next.children(':first-child').clone().appendTo($(this));
            if (next.next().length > 0) {
                next.next().children(':first-child').clone().appendTo($(this));
            } else {
                $(this).siblings(':first').children(':first-child').clone().appendTo($(this));
            }
        });

        // Must have lines in all controller
        $scope.init = function () {
            $scope.checkUserLogin();

            if ($rootScope.userCheckLogged !== undefined) {
                $scope.playZones();
                $scope.getTrendingData();
                $scope.getRecentGames();
                $scope.popularGames();
//                if (userData.userInfo.displayName == (null || undefined) || userData.userInfo.displayName == '') {
//                    $window.location.href = "#/editprofile"
//                }
            }
        }

        $scope.checkUserLogin = function () {
            $rootScope.userCheckLogged = $cookies.get('currentUser');
            console.log("Check Login", $rootScope.userCheckLogged);
            if ($rootScope.userCheckLogged === undefined) {
                $window.location.href = "#/login";
            }
        }

        //////////////////////

        function chunkArrayInGroups(array, unit) {
            var results = [],
                    length = Math.ceil(array.length / unit);

            for (var i = 0; i < length; i++) {
                results.push(array.slice(i * unit, (i + 1) * unit));
            }
            return results;
        }

        $scope.getTrendingData = function () {
            serviceCall.trendingGamesService(function (response) {
                commonService.log("Trending Data", response);
                $scope.trendingGames = response.result;

                var i = 1;
                var groupPair = 2;
                var arr = [];

                $scope.groupTendingGames = chunkArrayInGroups($scope.trendingGames, 2);

            });
        }





        $scope.getRecentGames = function () {
            serviceCall.recentGamesService(function (response) {
                console.log("Recent data Original", response);
                getSubjects();
                $scope.recentGames = response.result;
//                $scope.recentGames.isNewUser = false;
                console.log("Recent Data", JSON.stringify($scope.recentGames), $scope.subjects);
                if ($scope.recentGames.isNewUser) {
                    $scope.recentGames.recentActivites = $scope.subjects;
                }
            });
        }




        $scope.playZones = function () {
            if ($localStorage.playZones == undefined) {
                serviceCall.zoneDetailsService(function (response) {
                    //commonService.log("Playzone :" + response);
                    var result = response["result"];
                    var errorCode = response["errorCode"];
                    if (errorCode === 200) {
                        commonService.log("playzone error code => 200");
                        commonService.log("***************************");
                        $localStorage.playZones = result;
                    }
                    getSubjects();
                });
            }
        }

        function getSubjects() {
            var playZones = $localStorage.playZones;
            var subjectsList = playZones[0]["subjects"];
            var subjects = [];
            for (var i = 0; i < subjectsList.length; i++) {
                commonService.log("***************************** SubjectsList *******************");
                commonService.log(subjectsList[i]['title']);
                subjects[i] = subjectsList[i];
                commonService.log(subjects[i]);
            }
            $scope.subjects = subjectsList;
            $scope.isNewUser = true;
            for (var i = 0; i < subjects.length; i++) {
                commonService.log("***************************** Subjects *******************");
                commonService.log(subjects[i]);
            }

        }






        function parseTrending(json) {

            //var json = JSON.parse(jsonStr);

            var errorCode = json["errorCode"];
            var results;
            var subjects = [[]];
            subjects.flavor = [];
            if (errorCode === 200) {

                results = json["result"];
                for (var i = 0; i < results.length; i++) {
                    subjects[i] = results[i]["subject"];
                    subjects[i].title = subjects[i]["title"];
                    subjects[i].imageURL = subjects[i]["imageURL"];
                    subjects.flavor[i] = results[i]["flavor"];
                    subjects.flavor[i].title = subjects.flavor[i]["title"]
                    subjects.flavor[i].imageURL = subjects.flavor[i]["imageURL"];
                    commonService.log(subjects[i].title, subjects.flavor[i].title);
                }

            }

            return results;
        }

        $scope.popularGames = function () {
            serviceCall.popularGamesService(function (response) {
                commonService.log("popular : " + JSON.stringify(response));
                var popularGames = parsePopular(response);
                $scope.popularGames = popularGames;
            });
        }
        function parsePopular(json) {

            //var json = JSON.parse(jsonStr);

            var errorCode = json["errorCode"];
            var results;
            var subjects = [];
            subjects.flavor = [];
            if (errorCode === 200) {

                results = json["result"];
                for (var i = 0; i < results.length; i++) {
                    subjects[i] = results[i]["subject"];
                    subjects[i].title = subjects[i]["title"];
                    subjects[i].imageURL = subjects[i]["imageURL"];
                    subjects.flavor[i] = results[i]["flavor"];
                    subjects.flavor[i].title = subjects.flavor[i]["title"]
                    subjects.flavor[i].imageURL = subjects.flavor[i]["imageURL"];
                    commonService.log(subjects[i].title, subjects.flavor[i].title);
                }

            }

            return subjects;
        }


        function parseRecent(json) {

            var errorCode = json["errorCode"];
            var results;
            var subjects = [];
            var isNewUser;
            if (errorCode === 200) {
                results = json["result"];
                isNewUser = json["result"]["isNewUser"];
                if (!isNewUser) {
                    var recent = json["result"]["recentActivites"];
                    for (var i = 0; i < recent.length; i++) {
                        subjects[i] = recent[i]["subject"];
                        subjects[i].id = recent[i]["subject"]["id"];
                        subjects[i].name = recent[i]["subject"]["name"];
                        subjects[i].image = recent[i]["subject"]["image"];
                        subjects[i].flavor = recent[i]["flavour"];
                        subjects[i].flavor.id = recent[i]["flavour"]["id"];
                        subjects[i].flavor.name = recent[i]["flavour"]["name"];
                        subjects[i].flavor.image = recent[i]["flavour"]["image"];
                        subjects[i].flavor.stake = recent[i]["stake"];
                        subjects[i].flavor.stake.id = recent[i]["stake"]["id"];
                        subjects[i].flavor.stake.name = recent[i]["stake"]["name"];
                        subjects[i].flavor.stake.amount = recent[i]["stake"]["amount"];
                        commonService.log("************** Subject ******************");
                        commonService.log(subjects[i].name);
                        commonService.log("********************************************");
                        commonService.log(subjects[i].flavor.name);
                        commonService.log("*********************************************");
                        commonService.log(subjects[i].flavor.stake.name);
                    }
                }
            }
            return subjects;
        }


        $scope.isNewUser = true;
        commonService.log("Trending :" + JSON.stringify(trendingGames));
    }

})();

