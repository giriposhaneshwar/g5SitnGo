angular-jwt-authentication-example
==============================

AngularJS JWT Authentication Example

To see a demo and further details go to http://jasonwatmore.com/post/2016/04/05/AngularJS-JWT-Authentication-Example-Tutorial.aspx
