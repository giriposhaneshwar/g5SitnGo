﻿(function () {
    'use strict';

    angular
            .module('app')
            .controller('Wallet.IndexController', Controller);

    function Controller($scope, $rootScope, $location, $timeout, $window, $cookies, $q, $http, $interval, $localStorage, localStorageService, AuthenticationService, commonService, serviceCall, authService, ngAuthSettings) {
        var vm = this;
        
        var userData = localStorageService.get('userInfo');
     
        $rootScope.playMode = commonService.playModeDefault;
      
        $scope.initController = function () {
           
             FB.init({
                appId: '1099750626761695',
                cookie: true,
                status: true,
                xfbml: true
            });
        };
        $scope.initController();

        $scope.facebookInviteFriends=function()
        {
            FB.ui({
               method: 'apprequests',
                  message: 'Friend Smash Request!',
            });
        }
    
    
    
    }      

})();                                                                                                                                                            