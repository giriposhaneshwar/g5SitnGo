﻿'use strict';
angular.module('app').factory('authInterceptorService', ['$q', '$injector', '$window', '$location', 'localStorageService', function ($q, $injector, $window, $location, localStorageService) {

        var authInterceptorServiceFactory = {};
        var _request = function (config) {
            console.log("authInterceptorService Request - ", config);
            config.headers = config.headers || {};
            var authData = localStorageService.get('authorizationData');
            if (authData) {

                var strDateTime = authData.ExpiresIn;
                var myDate = new Date(strDateTime);
                var bTime = myDate.getTime();
                var cTime = new Date().getTime();
                var diff = (bTime - cTime) / 1000;
                console.log("KSKK  >>> ", bTime, cTime, diff);
                if (diff <= 3) {
                    var authService = $injector.get('authService');
                    //call refreshToken 
                    var newRefreshToken = authService.refreshToken();
                    //Set AuthData
                    newRefreshToken.then(function (res) {
                        console.log("if lestime:::::::", res);
                        authData = localStorageService.get('authorizationData');
                    });
                }


                config.headers.Authorization = 'Bearer ' + authData.token;
            }

            return config;
        };
        var _responseError = function (rejection) {
            console.log("authInterceptorService ResponseError - ", rejection);
            /*
			if (rejection.status === 407) {
                var authService = $injector.get('authService');
                var authData = localStorageService.get('authorizationData');
                if (authData) {
                    if (authData.useRefreshTokens) {
                        $location.path('/refresh');
                        return $q.reject(rejection);
                    }
                }
                authService.logOut();
                $location.path('/login');
            } else if (rejection.status === -1) {
                var authService = $injector.get('authService');
                var authData = localStorageService.get('authorizationData');
                if (authData) {
                    if (authData.useRefreshTokens) {
                        $location.path('/refresh');
                        authService.refreshToken();
                        return $q.reject(rejection);
                    }
                }
                authService.logOut();
                $location.path('/login');
            }
			*/
            return $q.reject(rejection);
        };
        authInterceptorServiceFactory.request = _request;
        authInterceptorServiceFactory.responseError = _responseError;
        return authInterceptorServiceFactory;
    }]);