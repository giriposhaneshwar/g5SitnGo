(function () {
    'use strict';
    angular
            .module('app')
            .factory('serviceCall', Service);
    function Service($http, $localStorage, $q, $cookies, $cacheFactory, localStorageService, ngAuthSettings, authService, commonService) {
        var service = {},
                deferred = $q.defer(),
                serviceBase = ngAuthSettings.apiServiceBaseUri,
                headerInfo = {headers: {'Content-Type': 'application/x-www-form-urlencoded'}};
        var httpRequestArgs = {
            url: "",
            obj: "",
            headers: "",
            file: false
        };
        service.postRequest = function (httpRequestArgs, cb) {
            var tStamp = new Date();

            /* Checking if the url has any params and assigning the timestamp*/
            var arr = httpRequestArgs.url.split('?');
            if (httpRequestArgs.url.length > 1 && arr[1] !== '') {
                if (arr.length > 1) {
                    var url = httpRequestArgs.url + "&v=" + tStamp.getTime();
                } else {
                    var url = httpRequestArgs.url + "?v=" + tStamp.getTime();
                }
            }

            var fileType = (httpRequestArgs.file === (undefined || false)) ? "" : "file";
            var method = (httpRequestArgs.obj === undefined) ? "GET" : "POST";
            $http.defaults.cache = false;
            var httpObj = {};
            httpObj.url = url;
            httpObj.method = method;
            if (httpRequestArgs.headers !== undefined) {
                httpObj.headers = httpRequestArgs.headers;
            }
            if (httpRequestArgs.obj !== undefined) {
                httpObj.data = httpRequestArgs.obj;
            }


            if (fileType === "file") {
                httpObj.transformRequest = angular.identity;
                httpObj.headers = {'Content-Type': undefined};
            }

            commonService.log("Http Options ", httpObj);
            var rtn = $http(httpObj).success(function (data, status, headers, config) {
                commonService.log("htp response", data);
                if ((data !== undefined || data !== null) && data.errorCode === 200) {
                    if (cb)
                        cb(data);
                } else {
                    if (cb)
                        cb(data);
                }
//                deferred.resolve(data);
            }).error(function (data, status, headers, config) {
                if (data !== undefined || data !== null) {
                    if (cb)
                        cb(data);
                } else {
                    commonService.log("Failed as the data response is failed", data);
                }
//                deferred.reject(data);
            });
//            return deferred.promise;
        };

        service.checkLogin = function (cb) {
            var loginCheck = {};
            var responseObj = {};
            loginCheck.user = $cookies.get('currentUser');
            loginCheck.name = $cookies.get('currentUserName');
            commonService.log("LoginCheck ", loginCheck);
            if (loginCheck.user === undefined && loginCheck.name === undefined) {
                responseObj.state = 'failed';
                responseObj.message = "please login!";
                responseObj.data = undefined;
            } else {
                responseObj.state = "success";
                responseObj.message = "User " + loginCheck.user + " Logged In!";
                responseObj.date = loginCheck;
            }
            if (cb)
                cb(responseObj);
        };
        var _authentication = {
            isAuth: false,
            userName: "",
            useRefreshTokens: true
        };

        service.trendingGamesService = function (cb) {
            httpRequestArgs = {
                url: serviceBase + "api/Account/Trending"
            }

            var call = service.postRequest(httpRequestArgs, function (response)
            {
                if (cb)
                    cb(response);
            });
        }
        service.recentGamesService = function (cb) {
            httpRequestArgs = {
                url: serviceBase + "api/Account/RecentActivity"
            }

            var call = service.postRequest(httpRequestArgs, function (response)
            {
                if (cb)
                    cb(response);
            });
        }

        service.zoneDetailsService = function (cb) {

            httpRequestArgs = {
                url: serviceBase + "/api/PlayZonesWithFavourites"
            };

            var call = service.postRequest(httpRequestArgs, function (response)
            {
                console.log("All subjects zoneDetails Service", response);
                if (cb)
                    cb(response);
            });
        };

        service.favouriteGamesService = function (data, cb) {
            httpRequestArgs = {
                url: serviceBase + "/api/Favorite"
            };

            var call = service.postRequest(httpRequestArgs, function (response)
            {
                if (cb)
                    cb(response);
            });
        };

        service.popularGamesService = function (cb) {
            httpRequestArgs = {
                url: serviceBase + "/api/Account/Popular"
            };

            var call = service.postRequest(httpRequestArgs, function (response)
            {
                if (cb)
                    cb(response);
            });
        };

        /* Method for Login User*/
        service.loginUser = function (loginData, cb) {
            loginData.grant_type = "password";
            loginData.useRefreshTokens = _authentication.useRefreshTokens;
            httpRequestArgs = {
                url: serviceBase + "Api/Account/Login",
                obj: loginData,
                file: false
            };
            service.postRequest(httpRequestArgs, function (response) {
                console.log("Login User Post", response);

                if (response !== null) {
                    if (response.errorCode === 200 && response !== null) {
                        localStorageService.set('currentUser', {username: response.result.userName, access_token: response.result.access_token});
                        localStorageService.set('userInfo', response.result);
                        $http.defaults.headers.common.Authorization = response.result.token_type + ' ' + response.result.access_token;
                        $cookies.put('currentUser', response.result.access_token);
                        $cookies.put('currentUserName', response.result.userName);
                        if (loginData.useRefreshTokens) {
                            localStorageService.set('authorizationData', {token: response.result.access_token, userName: response.result.userName, refreshToken: response.result.refresh_token, ExpiresIn: response.result['.expires'], useRefreshTokens: true});
                        } else {
                            localStorageService.set('authorizationData', {token: response.result.access_token, userName: response.result.userName, refreshToken: "", useRefreshTokens: false});
                        }
                        _authentication.isAuth = true;
                        _authentication.userName = response.result.userName;
                        _authentication.useRefreshTokens = loginData.useRefreshTokens;
                        if (cb)
                            cb(response);
                    } else {
                        if (cb)
                            cb(response);
                    }
                } else {
                    console.log("Response at Post Request is empty", response);
                }
            });
        };

        /* Method for Register User*/
        service.registerUserService = function (data, cb) {
            httpRequestArgs = {
                url: serviceBase + "api/Account/Register",
                obj: data,
                headers: "",
                file: false
            };
            service.postRequest(httpRequestArgs, function (response) {
                if (cb)
                    cb(response);
            });
        };


        service.logoutUser = function (cb) {
            $cookies.remove('currentUser');
            $cookies.remove('currentUserName');
            var arr = commonService.localStorageArr;
            angular.forEach(arr, function (a, b) {
                if (a !== undefined) {
                    localStorageService.remove(a);
                }
            });

            $http.defaults.headers.common.Authorization = '';
            var obj = {};
            obj.status = ($cookies.get('currentUser') === undefined || "") ? "success" : "failed";
            if (cb)
                cb(obj);
        };

        service.forgotPassword = function (data, cb) {
            httpRequestArgs = {
                url: serviceBase + "api/Account/ForgotPassword?email=" + data,
                obj: ""
            };
            var call = service.postRequest(httpRequestArgs, function (response) {

                if (cb)
                    cb(response);
            });
        }
        service.resetPasswordService = function (data, cb) {
            httpRequestArgs = {
                url: serviceBase + "api/Account/ResetPassword",
                obj: data,
                headers: "",
                file: false
            };
            var call = service.postRequest(httpRequestArgs, function (response) {

                if (cb)
                    cb(response);
            });
        }
        service.changePassword = function (data, cb) {
            httpRequestArgs = {
                url: serviceBase + "api/Account/ChangePassword",
                obj: data,
                headers: "",
                file: false
            };
            var call = service.postRequest(httpRequestArgs, function (response) {

                if (cb)
                    cb(response);
            });
        }
        service.getValues = function (cb) {

            httpRequestArgs = {
                url: serviceBase + "api/Values",
                obj: ""
            };
            var call = service.postRequest(httpRequestArgs, function (response) {
                if (cb)
                    cb(response);
            });
        }

        service.getProfileService = function (cb) {
            httpRequestArgs = {
                url: serviceBase + "api/Account/Profile",
                file: false
            };
            service.postRequest(httpRequestArgs, function (response) {
                commonService.log("Edit Profile Response", response);
                if (cb)
                    cb(response);
            });
        }

        service.resendActicationCodeService = function (data, cb) {
            httpRequestArgs = {
                url: serviceBase + "api/Account/ResendVerificationCode?vcf=Email&email=" + data,
                obj: data,
                headers: "",
                file: true
            };
            service.postRequest(httpRequestArgs, function (response) {
                commonService.log("Resend Varification Code Message", response);
                if (cb)
                    cb(response);
            });
        };
        service.verifyUserService = function (data, cb) {
            httpRequestArgs = {
                url: serviceBase + "api/Account/ConfirmEmail" + "?userId=" + data.Email + "&code=" + data.Code,
                file: false
            };

            service.postRequest(httpRequestArgs, function (response) {
                commonService.log("Activation Service Message", response);
                if (cb)
                    cb(response);
            });
        };
        service.verifyUserAndLoginService = function (data, cb) {
            commonService.log("Verificaiton And Login Service at ServiceCall ::: 319", data);

            httpRequestArgs = {
                url: serviceBase + "api/Account/ConfirmEmailAndLogin" + "?userId=" + data.Email + "&password=" + data.Password + "&code=" + data.Code,
                file: false
            };

            service.postRequest(httpRequestArgs, function (response) {
                commonService.log("Activation Service Message", response);

                if (response.errorCode === 200) {
                    localStorageService.set('currentUser', {username: response.result.userName, access_token: response.result.access_token});
                    localStorageService.set('userInfo', response.result);
                    localStorageService.currentUser = {username: response.result.userName, access_token: response.result.access_token};
                    $http.defaults.headers.common.Authorization = response.result.token_type + ' ' + response.result.access_token;
                    $cookies.put('currentUser', response.result.access_token);
                    $cookies.put('currentUserName', response.result.userName);
                    $cookies.put('currentUserName', response.result.userName);
                    if (response.result.useRefreshTokens) {
                        localStorageService.set('authorizationData', {token: response.result.access_token, userName: response.result.userName, refreshToken: response.result.refresh_token, ExpiresIn: response.result['.expires'], useRefreshTokens: true});
                    } else {
                        localStorageService.set('authorizationData', {token: response.result.access_token, userName: response.result.userName, refreshToken: "", useRefreshTokens: false});
                    }
                    _authentication.isAuth = true;
                    _authentication.userName = response.result.userName;
                    _authentication.useRefreshTokens = response.result.useRefreshTokens;

                    if (cb)
                        cb(response);
                } else {
                    if (cb)
                        cb(response);
                }
            });
        };
        service.resendForgotPasswordService = function (data, cb) {
            commonService.log("Resend Forgot Service 319::::", data);
            httpRequestArgs = {
                url: serviceBase + "api/Account/ForgotPassword" + "?vcf=Password&email=" + data,
                obj: "",
                file: false
            };

            service.postRequest(httpRequestArgs, function (response) {
                commonService.log("Forgot Password Response in Service 326::::::", response);
                if (cb)
                    cb(response);
            });
        };

        service.createGamy5UserService = function (data, cb) {
            httpRequestArgs = {
                url: serviceBase + "Api/Account/CreateGamy5Account",
                obj: data,
                headers: "",
                file: false
            };
            service.postRequest(httpRequestArgs, function (response) {
                commonService.log("Create Gamy5 Account Service :::301", response);


                if (response.errorCode === 200) {

                    if (cb)
                        cb(response);
                } else {
                    if (cb)
                        cb(response);
                }
            });
        };
        service.getCountry = function (cb) {
            httpRequestArgs = {
                url: serviceBase + "api/Country",
                file: false
            };
            service.postRequest(httpRequestArgs, function (response) {
                commonService.log("Edit Profile Response", response);
                if (cb)
                    cb(response);
            });
        };
        service.getState = function (id, cb) {
            httpRequestArgs = {
                url: serviceBase + "api/State?countryId=" + id,
                file: false
            };
            service.postRequest(httpRequestArgs, function (response) {
                commonService.log("Get States Response", response);
                if (cb)
                    cb(response);
            });
        };
        service.getFavoritesService = function (cb) {
            httpRequestArgs = {
                url: serviceBase + "api/Favorite"
            };
            service.postRequest(httpRequestArgs, function (response) {
                commonService.log("Get Favorites Service Response", response);
                if (cb)
                    cb(response);
            });
        }

        service.addFavoriteService = function (data, cb) {
            httpRequestArgs = {
                url: serviceBase + "api/Favorite",
                obj: JSON.stringify(data)
            };
            service.postRequest(httpRequestArgs, function (response) {
                commonService.log("Get Favorites Service Response", response);
                if (cb)
                    cb(response);
            });
        }
        service.removeFavoriteService = function (id, cb) {
            console.info("Favourite Remove", id);
            httpRequestArgs = {
                url: serviceBase + "api/Favorite/Remove?favoriteId=" + id,
                obj: ""
            };
            service.postRequest(httpRequestArgs, function (response) {
                commonService.log("Get Favorites Service Response", response);
                if (cb)
                    cb(response);
            });
        }

        return service;
    }

})();