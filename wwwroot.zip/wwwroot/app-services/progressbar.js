(function () {
    'use strict';
    angular
        .module('app')
        .factory('progressbar', ['$rootScope', function ($rootScope) {

            return progressbar;
        }])
})()