(function() {
    'use strict';
    angular.module('app').
    directive('fileUpload', function() {
        return {
            scope: true, //create a new scope
            link: function(scope, el, attrs) {
                el.bind('change', function(event) {
                    /*
                     console.log("Directive Attrs: ", attrs);
                     console.log("Directive el: ", el);
                     */
                    var files = event.target.files;
                    var name = attrs['name'];
                    //iterate files since 'multiple' may be specified on the element
                    for (var i = 0; i < files.length; i++) {
                        //emit event upward
                        scope.$emit("fileSelected", { name: name, file: files[i] });
                    }
                });
            }
        };
    }).
    directive('emailFormat', function($parse) {
        return {
            require: 'ngModel',
            link: function(scope, element, attrs, ctrl) {
                ctrl.$parsers.unshift(function(viewValue, $scope) {
                    var model = $parse(attrs.ngPattern);
                    var email = viewValue.match(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/igm);
                    //                    console.log(scope.registrationFrom.email.$viewValue);
                    ctrl.$setValidity('email', !email)

                });
            }
        }
    }).
    filter('unique', function() {

        return function(arr, field) {
            commonService.log("Unique Array ", arr, field);
            var o = {},
                i, l = arr.length,
                r = [];
            for (i = 0; i < l; i += 1) {
                o[arr[i][field]] = arr[i];
            }
            for (i in o) {
                r.push(o[i]);
            }
            return r;
        };
    }).
    directive('fileModel', ['$parse', function($parse) {
        return {
            restrict: 'A',
            link: function(scope, element, attrs) {
                var model = $parse(attrs.fileModel);
                var modelSetter = model.assign;
                element.bind('change', function() {
                    //                        commonService.log("File Uplod  ;;;;;;;; \n Scope: ", scope, "\n Element : ", element, "\n Attrs : ", attrs);
                    scope.$apply(function() {
                        modelSetter(scope, element[0].files[0]);
                    });
                });
            }
        };
    }]).
    directive('alphaValidator', function($parse) {
            return {
                link: function(scope, elm, attrs) {
                    elm.bind('keypress', function(e) {
                        var char = String.fromCharCode(e.which || e.charCode || e.keyCode),
                            matches = [];
                        var regex = /^[a-zA-Z]+$/;
                        //var regex = /^(\s)/;
                        if (regex.test(char) || char.charCodeAt(0) == 8 || char.charCodeAt(0) == 27 || char.charCodeAt(0) == 9 || char.charCodeAt(0) == 32)
                            matches.push(char);
                        else if (matches.length == 0) {
                            e.preventDefault();
                            return false;
                        }
                    });
                }
            }
        }).directive('specialValidator', function($parse) {
            return {
                link: function(scope, elm, attrs) {
                    elm.bind('keypress', function(e) {
                        var char = String.fromCharCode(e.which || e.charCode || e.keyCode),
                            matches = [];

                        //                            var regex = /^[ A-Za-z0-9$@_-]+$/;
                        var regex = /^[a-zA-Z0-9!@`#$&()\\-`.+,:;*\"_'<>{=?|}[~]]*$/;
                        //var regex = /^(\s)/;
                        if (regex.test(char) || char.charCodeAt(0) == 8 || char.charCodeAt(0) == 27 || char.charCodeAt(0) == 9 || char.charCodeAt(0) == 32)
                            matches.push(char);
                        else if (matches.length == 0) {
                            e.preventDefault();
                            return false;
                        }
                    });
                }
            }
        })
        .directive('numericValidator', function($parse) {
            return {
                link: function(scope, elm, attrs) {
                    elm.bind('keypress', function(e) {
                        var char = String.fromCharCode(e.which || e.charCode || e.keyCode),
                            matches = [];
                        var regex = /^[0-9]+$/;
                        var match = regex.test(char);
                        if (match || char.charCodeAt(0) == 8 || char.charCodeAt(0) == 27 || char.charCodeAt(0) == 9)
                            matches.push(char);
                        if (matches.length == 0) {
                            e.preventDefault();
                            return false;
                        }
                    });
                }
            }
        }).
    directive("limitTo", function() {
        return {
            restrict: "A",
            link: function(scope, elem, attrs) {
                var limit = parseInt(attrs.limitTo);
                elem.bind("keypress", function(e) {
                    if (this.value.length == limit && e.keyCode != 8 && e.keyCode != 27)
                        e.preventDefault();
                });
            }
        }
    }).
    directive('freePaid', function($parse, $window, commonService, localStorageService) {
        return {
            restrict: 'EA',
            templateUrl: "./assets/partials/freePaid.html",
            replace: true,
            scope: {},
            controller: function() {

            },
            link: function(scope, element, attrs) {
                console.log("Calling the function \n", scope, element, attrs);
                scope.init = function() {
                    scope.units = commonService.playModeDefault;
                    scope.playAmt = scope.units == 'free' ? "50 Coins" : "Rs. 250";
                }
                scope.init();
                scope.callMe = function() {
                    scope.units = (scope.units == "free") ? "paid" : "free";
                    scope.playAmt = scope.units == 'free' ? "50 Coins" : "Rs. 250";
                    scope.udInfo = commonService.getLocalStorage('userInfo');
                    var t = commonService.checkGamy5User(scope.udInfo);
                    if (!t) {
                        $window.location.href = "#/signUp";
                    }
                }
            }
        };
    }).
    directive('registrationExternal', function($window, $routeParams, $timeout, commonService, localStorageService, serviceCall) {
        return {
            restrict: "A",
            controller: function($scope) {

                $scope.id = $routeParams.id;
            },
            //replace: true,
            templateUrl: "./assets/partials/register.view.html",
            scope: {
                text: '@text'
            },
            link: function(scope, $attr) {

                scope.inputType = "password";
                scope.showPassword = function() {

                    if (scope.inputType == "password")
                        scope.inputType = "text";
                    else
                        scope.inputType = "password";

                }


                scope.userDetails = { Email: "", Password: "", ConfirmPassword: "", "referCode": "" };
                if (scope.id != (undefined || null)) {
                    scope.userDetails.referCode = scope.id;
                    var authdata = localStorageService.get('authorizationData');
                    if (authdata != null && authdata.token != (null || undefined)) {
                        $window.location.href = commonService.landingPage;
                    }
                };

                var ud = localStorageService.get('userInfo');

                //registration for Gamy5user
                if (ud != (null || undefined)) {

                    scope.isEmailDisable = false;

                    if (ud.userInfo.email != (undefined || null)) {

                        if (!ud.isEmailVerified) {
                            scope.userDetails.Email = ud.userInfo.email;
                            scope.isEmailDisable = false;
                        } else {
                            scope.userDetails.Email = ud.userInfo.email;
                            scope.isEmailDisable = true;
                        }
                    }
                }



                scope.emailPattern = commonService.emailPattern;
                scope.PasswordPattern = commonService.passwordPattern;
                scope.registerUser = function(evt, postData) {
                    evt.preventDefault();
                    if (ud != (null || undefined)) {

                        scope.Gamy5userDetails = { userName: "", password: "", rememberMe: true };
                        scope.Gamy5userDetails.userName = scope.userDetails.Email;
                        scope.Gamy5userDetails.password = scope.userDetails.Password;
                        scope.userDetails.ConfirmPassword = scope.userDetails.Password;
                        if (scope.Gamy5userDetails.userName != undefined && scope.Gamy5userDetails.password != undefined) {
                            console.log(scope.Gamy5userDetails);
                            serviceCall.createGamy5UserService(scope.Gamy5userDetails, function(res) {

                                commonService.log("Response Register Request", typeof res, res);
                                if (res.errorCode === 200) {
                                    scope.activationRequest = true;
                                    scope.err = true;
                                    scope.errStatus = true;
                                    scope.statusMessage = res.result;
                                    localStorageService.set('_g5_ud', btoa(JSON.stringify(scope.userDetails)));

                                    if (!ud.isEmailVerified) {
                                        $window.location.href = "#/activate";
                                    } else {
                                        ud.hasGamy5Account = true;
                                        localStorageService.set('userInfo', ud);
                                        $timeout(function() {

                                            $window.location.href = commonService.landingPage;
                                        }, commonService.redirectTime);
                                    }
                                } else {
                                    // working with failed message
                                    scope.statusMessage = res.errorMessage;
                                    scope.errStatus = false;
                                    scope.err = true;
                                }
                            });
                        } else {
                            scope.statusMessage = "Could not post the form please recheck the fileds";
                            scope.errStatus = false;
                            scope.err = true;
                        }

                    } else {
                        scope.userDetails.ConfirmPassword = scope.userDetails.Password;
                        if (scope.userDetails.Email != undefined && scope.userDetails.Password != undefined && scope.userDetails.ConfirmPassword != undefined) {
                            console.log(scope.userDetails)
                            serviceCall.registerUserService(scope.userDetails, function(res) {

                                commonService.log("Response Register Request", typeof res, res);
                                if (res.errorCode === 200) {
                                    scope.activationRequest = true;
                                    scope.err = true;
                                    scope.errStatus = true;
                                    scope.statusMessage = res.result;
                                    localStorageService.set('_g5_ud', btoa(JSON.stringify(scope.userDetails)));

                                    $timeout(function() {

                                        $window.location.href = "#/activate";
                                    }, 3000);
                                } else {
                                    // working with failed message
                                    scope.statusMessage = res.errorMessage;
                                    scope.errStatus = false;
                                    scope.err = true;
                                }
                            });
                        } else {
                            scope.statusMessage = "Could not post the form please recheck the fileds";
                            scope.errStatus = false;
                            scope.err = true;
                        }
                    }

                };
                /* Restricting the Space to enter in user name filed */
                scope.restrictKeys = function(e, k) {
                    commonService.log("this value", e.currentTarget.value, "RestrictKeys-44");
                    if (e.which === k) {
                        return false;
                    };
                    e.currentTarget.value = e.currentTarget.value.replace(/\s/g, "");
                };
                scope.paidUser = function(evt, data) {
                    console.log("Paidn User ", data);
                    if (data.paidRegister === true) {
                        $window.location.href = "#/paid-register";
                    };
                };



            }
        }
    }).
    directive('registrationActivation', function($parse, $window, localStorageService, commonService, serviceCall) {
        return {
            restrict: "A",
            controller: function() {},
            //replace: true,
            scope: {},
            templateUrl: "./assets/partials/activation.view.html",
            link: function(scope) {


                scope.init = function() {

                    scope.userData = JSON.parse(atob(localStorageService.get('_g5_ud')));
                    console.log("user data on active screeen is ", scope.userData);
                }
                scope.init();

                scope.activateUser = function(evt, data) {
                    evt.preventDefault();
                    console.log("User Activation Submition", data);

                    data.Email = scope.userData.Email;
                    data.Password = scope.userData.Password;

                    if (typeof data !== "object") {
                        scope.err = true;
                        scope.errStatus = true;
                        scope.statusMessage = "Please fill all the fields!";
                    } else {
                        scope.err = false;

                        // submit the form
                        serviceCall.verifyUserAndLoginService(data, function(response) {
                            commonService.log("Email Activation Log on 91", response);
                            if (response.errorCode === 200) {
                                $("#activeSuccess").modal({ backdrop: 'static', keyboard: true, show: true });
                                //scope.err = true;
                                //scope.errStatus = true;
                                // scope.statusMessage = response.result;
                                console.log(response.result);
                                localStorageService.set("userInfo", response.result);
                                scope.displayName = response.result.displayName;

                            } else {
                                scope.err = true;
                                scope.errStatus = false;
                                scope.statusMessage = response.errorMessage;
                            }
                        });


                    }
                }
                scope.continuePage = function() {
                    $('body').removeClass().removeAttr('style');
                    $('.modal-backdrop').remove();
                    if (scope.displayName == (null || undefined) || scope.displayName == '') {
                        $window.location.href = '#/editProfile';
                    } else {
                        $window.location.href = commonService.landingPage;
                    }
                }
                scope.resedActivationCode = function() {
                    serviceCall.resendActicationCodeService(scope.userData.Email, function(response) {
                        commonService.log("Response or Resend ActivationCode Service Success/Fail", response);

                        if (response.errorCode === 200) {
                            scope.err = true;
                            scope.errStatus = true;
                            scope.statusMessage = response.result;
                        } else {
                            scope.err = true;
                            scope.errStatus = false;
                            scope.statusMessage = res.result;
                        }
                    });
                };




            }
        }
    }).
    directive("bnDocumentClick", function($document, $parse) {
        var linkFunction = function($scope, $element, $attributes) {
            var scopeExpression = $attributes.bnDocumentClick;
            var invoker = $parse(scopeExpression);
            $document.on("click", function(event) {
                $scope.$apply(function() {
                    invoker($scope, {
                        $event: event
                    });
                });
            });
        };
        return (linkFunction);

    }).
    directive("thumbSlider", function($parse, $window, localStorageService, commonService, serviceCall) {
        return {
            restrict: 'A',
            scope: {},
            link: function(scope, el, attr) {
                var items = scope;
                console.log("From Thumb Slider", scope.recentGames, items);

            }
        }
    }).
    directive('thumbSlider', ['$timeout', '$interval', function($timeout, $interval) {
        function link($scope, elem, attr) {
            elem.prepend('<div class="thumbSlider-controls col-xs-12"><div class="col-xs-6"><a href="javascript:void(0)" class="next left-icon"><img src="assets/images/sitnGo/Floavours-arrow-left_7x14.svg" width="7" height="14"></a></div><div class="col-xs-6 pull-right"><a href="javascript:void(0)" class="previous pull-right right-icon"><img src="assets/images/sitnGo/Floavours-arrow-right_7x14.svg" width="7" height="14"></a></div></div>');
            //                        console.log("$scope.carouselList", $scope);
            var previousButton = angular.element(elem[0].querySelector('.previous')),
                nextButton = angular.element(elem[0].querySelector('.next'));
            var list = angular.element(elem[0].querySelector('ul')),
                content = angular.element(elem[0].querySelector('.carousel-content')),
                position = 0,
                limit = function() {
                    return -(content[0].getBoundingClientRect().width - list[0].getBoundingClientRect().width)
                },
                contentBigger = function() {
                    return content[0].getBoundingClientRect().width > list[0].getBoundingClientRect().width;
                };
            var hoverTimeout = null,
                hoverInterval = null;
            $scope.$watch('carouselList', function() {
                //                            console.log('changed!')
                move(0);
            });
            nextButton.on('click', function() {
                $timeout.cancel(hoverTimeout);
                $interval.cancel(hoverInterval);
                position = Math.max(position - 280, limit());
                //                            console.log(limit(), position);
                move(position);
            });
            //                        nextButton.on('mouseover', function () {
            //                            hoverTimeout = $timeout(function () {
            //                                hoverInterval = $interval(function () {
            //                                    position = Math.max(position - 100, limit());
            //                                    console.log(limit(), position);
            //                                    move(position);
            //                                }, 200);
            //                            }, 100);
            //                        });
            //                        nextButton.on('mouseleave', function () {
            //                            $timeout.cancel(hoverTimeout);
            //                            $interval.cancel(hoverInterval);
            //                        });
            previousButton.on('click', function() {
                $timeout.cancel(hoverTimeout);
                $interval.cancel(hoverInterval);
                position = Math.min(position + 280, 0);
                //                            console.log(limit(), position);
                move(position);
            });
            //                        previousButton.on('mouseover', function () {
            //                            hoverTimeout = $timeout(function () {
            //                                hoverInterval = $interval(function () {
            //                                    position = Math.min(position + 100, 0);
            //                                    console.log(limit(), position);
            //                                    move(position);
            //                                }, 200);
            //                            }, 100);
            //                        });
            //                        previousButton.on('mouseleave', function () {
            //                            $timeout.cancel(hoverTimeout);
            //                            $interval.cancel(hoverInterval);
            //                        });
            function move(value) {
                if (value === 0) {
                    //                                previousButton.addClass('ng-hide');
                    previousButton.addClass('disable');
                } else {
                    previousButton.removeClass('disable');
                }
                if (value === limit()) {
                    nextButton.addClass('disable');
                } else {
                    nextButton.removeClass('disable');
                }
                if (contentBigger()) {
                    content.css('transform', 'translate3d(' + value + 'px, 0, 0)');
                }
            }
        }
        return {
            restrict: 'C',
            link: link,
            scope: {
                carouselList: '='
            }
        }
    }]);
}());
