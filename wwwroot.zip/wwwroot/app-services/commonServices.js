(function () {
    'use strict';
    angular
            .module('app')
            .factory('commonService', Service);
    function Service($http, $rootScope, $localStorage, $q, $cookies, $cacheFactory, localStorageService, ngAuthSettings, authService) {
        var c = {};

        // Constants
        c.fileSize = 512;
        c.showLogs = false;
        c.landingPage = "#/dashboard";
        c.playModeDefault = "free";
        c.emailPattern = /^[a-z]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/;
        c.passwordPattern = /(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z])(?=.*[@|_|.|$])/;
        c.localStorageArr = ['authorizationData', 'userInfo', 'currentUser', 'provider', '_g5_ud'];
        c.redirectTime = 3000;

        // methods
        c.emailFormat = function (email) {
            return true;
        };
        c.dateToLocal = function (dt) {
            var dob = new Date(dt);
            var changedDate = (dob.getMonth() + 1) + "-" + dob.getDate() + "-" + dob.getFullYear();
            return changedDate;
        };
        c.dateToGlobal = function (dt) {
            var n = new Date(dt);
            var convertedDate = n.getFullYear() + "-" + (n.getMonth() + 1) + "-" + n.getDate() + "T" + (n.getHours() + 1) + ":" + (n.getMinutes() + 1) + ":" + (n.getSeconds() + 1);

//            alert(dt + "  ||||  " + n + "  ||||  " + convertedDate);
            return convertedDate;
        };
        c.standardTimeFormat = function (dt) {
            var n = new Date(dt);

            var convertedDate = (n.getMonth() + 1) + "-" + n.getDate() + "-" + n.getFullYear();

//            alert(dt + "  ||||  " + n + "  ||||  " + convertedDate);
            return convertedDate;
        };
        c.log = function () {
            var args = arguments;
            var output = [];
            for (var i = 0; i < arguments.length; i++) {
                if (typeof arguments[i] == "object") {
                    arguments[i] = JSON.stringify(arguments[i]);
                }
                output.push(arguments[i]);
            }
            if (c.showLogs) {
                var check = output.indexOf("logFalse") > -1;
                if (!check) {
                    console.log(output.join());
                }
            }
        }
        c.safeApply = function (fn, scope) {
            var phase = scope.$root.$$phase;
            console.log("Phase result", phase);
            if (phase == '$apply' || phase == '$digest') {
                if (fn && (typeof (fn) === 'function')) {
                    fn();
                }
            } else {
                this.$apply(fn);
            }
        };
        c.checkGamy5User = function (ud) {
            if (ud.hasGamy5Account) {
                // gamy5 user

                return true;
            } else {
                // check with email or without emial
                if (ud.userInfo.email !== null) {
                    // came with email id

                    return false;
                } else {
                    // came with number

                    return false;
                }
            }
        }

        c.getLocalStorage = function (key) {
            return localStorageService.get(key);
        }
        c.storePlayZoneDataService = function (data, cb) {
//            var pzd = (typeof data === "Object") ? JSON.stringify(data) : data;
            var msg = {status: true};
            $localStorage.playZones = data;
            if (cb)
                cb(msg);
        }
        c.storeDataService = function (data, key) {
            $localStorage[key] = data;
        }
        c.pullStoreData = function (key) {
            return $localStorage[key];
        }
        return c;
    }

})();