(function () {
    'use strict';
    angular
            .module('app')
            .factory('signalRService', ['$rootScope', '$cookies', '$localStorage', 'localStorageService', 'commonService', 'serviceCall', function ($rootScope, $cookies, $localStorage, localStorageService, commonService, serviceCall) {
                    var data;
                    function backendFactory(backendServerUrl, hubName, GameTableID, PlayerID) {

                        console.log('backendFactory' + backendServerUrl + " " + hubName + " " + GameTableID + " " + PlayerID);
                        var connection = $.hubConnection(backendServerUrl);
                        if ($cookies.get('currentUser') !== undefined) {
                            var accessToken = $cookies.get('currentUser');
//                            var accessToken = 'T-_oYLmwSvIBq_qxJ9Pg5GsqkmO3wFpD1y-5E1Hbpdoz_5beCnpdLd1H0StloEAsRZFrayF_l3EEvsjwETs130W_NDzpMoDy4WM3rMtxIKd2HwK9Irs4WWBMsvPV5wuJLgXZhUF72SDclqYCvyB2ducdpwMa7tawzx-YXh33sq5Ceg5QCc9PgX1alKAtFfstLBn8iLXWYba5nA68p_7Gu44S45OrMYxy4spRsqBR2f_4yp49llyJaDQxECRSyvkZMdbwnmvENx0lt2zi50Wew9M3DJntqfQoSNweAelCC-Dsd1CHnSmarIyzhdKikYN6N1IrvxeUTsUuzGU8OOQ5PPjobRQTFehE2teK4TskjFTFqN_HWZ4ILmPivTMqvNPjQU0-MV-95soWoiVWJAAXrw';
                        } else {
                            var accessToken = 'no accesstoken';
                        }
                        connection.qs = {'access_token': accessToken};
                        var proxy = connection.createHubProxy(hubName);
                        connection.logging = true;
                        proxy.on("JoinPlayerToTable", function (zoneMsg) {
                            var method = "JoinPlayerToTable";
                            //                            alert(method, JSON.stringify(zoneMsg));
                            console.log(method, zoneMsg);
                            updateResponse(method, zoneMsg);
                        });
                        proxy.on("sendMessage", function (zoneMsg) {
                            var method = "sendMessage";
                            //                            alert(method, JSON.stringify(zoneMsg));
                            console.log(method, zoneMsg);
                            updateResponse(method, zoneMsg);
                        });
                        proxy.on("playerJoinMessage", function (zoneMsg) {
                            var method = "playerJoinMessage";
                            //                            alert(method, JSON.stringify(zoneMsg));
                            console.log(method, zoneMsg);
                            updateResponse(method, zoneMsg);
                        });
                        proxy.on("sendGameStart", function (zoneMsg) {
                            var method = "sendGameStart";
                            //                            alert(method, JSON.stringify(zoneMsg));                             console.log(method, zoneMsg);
                            updateResponse(method, zoneMsg);
                        });
                        proxy.on("StartGame", function (zoneMsg) {
                            var method = "StartGame";
                            //                            alert(method, JSON.stringify(zoneMsg));
                            console.log(method, zoneMsg);
                            updateResponse(method, zoneMsg);
                        });
                        proxy.on("sendQuestion", function (zoneMsg) {
                            var method = "sendQuestion";
                            //                            alert(method, JSON.stringify(zoneMsg));
                            console.log(method, zoneMsg);
                            updateResponse(method, zoneMsg);
                        });
                        proxy.on("sendAnswer", function (zoneMsg) {
                            var method = "sendAnswer";
                            //                            alert(method, JSON.stringify(zoneMsg));
                            console.log(method, zoneMsg);
                            updateResponse(method, zoneMsg);
                        });
                        proxy.on("sendGameResults", function (zoneMsg) {
                            var method = "sendGameResults";
                            //                            alert(method, JSON.stringify(zoneMsg));
                            console.log(method, zoneMsg);
                            updateResponse(method, zoneMsg);
                        });
                        proxy.on("sendExitMessage", function (zoneMsg) {
                            var method = "sendExitMessage";
//                            alert(method, JSON.stringify(zoneMsg));
                            console.log(method, zoneMsg);
                            $rootScope.gameMessage = {message: zoneMsg, method: method}
                        });
                        connection.start({transport: ['webSockets', 'longPolling', 'foreverFrame', 'serverSentEvents'], jsonp: true, xdomain: true}).done(function () {
                            alert('start');
                            proxy.invoke("JoinPlayerToTable", GameTableID, PlayerID).done(function (data) {
                                var method = "JoinPlayerToTable";
                                console.log(method, data);
                                $rootScope.gameObj['userInfo'] = data;
                                updateResponse(method, data);
                            });
                        });
                        function updateResponse(method, data) {
                            $rootScope.$apply(function () {
                                $rootScope.gameMessage = {method: method, message: data};
                            });
                        }


                        return {
                            //                            get: function (eventName) {
                            //                                if (eventName === "JoinTable") {
//
                            //                                    return $localStorage.playerData;
//                                }
                            //                            },
                            on: function (eventName, callback) {
                                console.log("on method called : " + eventName + " cb :" + callback());
                                proxy.on(eventName, function (result) {
                                    console.log("Start Game REsponse", result);
                                    $rootScope.$apply(function () {
                                        if (callback) {
                                            alert("CallaBack");
                                            callback(result);
                                        }
                                    });
                                });
                            },
                            invoke: function (methodName, params, callback) {
                                if (methodName === "ExitTable") {
                                    proxy.invoke(methodName, params)
                                            .done(function (result) {
                                                $rootScope.$apply(function () {
                                                    if (callback) {
                                                        callback(result);
                                                    }
                                                });
                                            });
                                } else if (methodName === "SubmitAnswer") {
                                    proxy.invoke(methodName, params)
                                            .done(function (result) {
                                                $rootScope.$apply(function () {
                                                    if (callback) {
                                                        callback(result);
                                                    }
                                                });
                                            });
                                }

                            },
                            connectionClose: function () {
                                connection.stop();
                            }
                        }
                    }

                    return backendFactory;
                }])
})();