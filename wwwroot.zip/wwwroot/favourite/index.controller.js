﻿(function () {
    'use strict';
    angular
            .module('app')
            .controller('Favourite.IndexController', Controller);

    function Controller($scope, $rootScope, $location, $timeout, $window, $cookies, $http, $interval, $localStorage, localStorageService, AuthenticationService, commonService, serviceCall, authService, ngAuthSettings, $routeParams) {

        $scope.params = $routeParams;

        $scope.checkUserLogin = function () {
            $rootScope.userCheckLogged = $cookies.get('currentUser');
            console.log("Check Login", $rootScope.userCheckLogged);
            if ($rootScope.userCheckLogged === undefined) {
                $window.location.href = "#/login";
            }
        }

        // Must have lines in all controller
        $scope.init = function () {
            $scope.checkUserLogin();
            if ($rootScope.userCheckLogged !== undefined) {
                $scope.playZones();
                $scope.setDefaultSubject($scope.params);
            }
        }
        $scope.setDefaultSubject = function (params) {
            console.log("params are", params);

            if (params.subject === undefined) {
                console.log("Alllll subjects", $scope.subjects);
                params.subject = $scope.subjects[0].subjectId;
            }

        }
        $scope.playZones = function () {
            if ($localStorage.playZones == undefined) {
                serviceCall.zoneDetailsService(function (response) {
                    //commonService.log("Playzone :" + response);
                    var result = response["result"];
                    var errorCode = response["errorCode"];
                    if (errorCode === 200) {
                        commonService.log("playzone error code => 200");
                        commonService.log("***************************");
                        commonService.storePlayZoneDataService(result);
                    }
                    getSubjects();
                });
            } else {
                getSubjects();
            }
        }

        function getSubjects() {
            var playZones = commonService.pullStoreData("playZones");
            console.log("PlaylistZone", playZones);
            var subjects = [];
            var subjectsList = playZones[0]["subjects"];


            console.log("All Subjects are from get subjects", subjectsList);
            for (var i = 0; i < subjectsList.length; i++) {
                subjects[i] = subjectsList[i];
                for (var j = 0; j < subjects[i].flavors.length; j++) {
                    subjects[i].flavors[j]['isFavorite'] = 0;
                    subjects[i].flavors[j]['subjectId'] = subjects[i].subjectId;
                }
            }
            $scope.subjects = subjectsList;
            $scope.isNewUser = true;
            for (var i = 0; i < subjects.length; i++) {
                commonService.log("***************************** Subjects *******************");
                commonService.log(subjects[i]);
            }
        }

    }
})();


