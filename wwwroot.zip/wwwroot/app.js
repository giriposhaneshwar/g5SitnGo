//var serviceBase = 'http://localhost:1793/';
//    var serviceBase = 'http://ngauthenticationapi.azurewebsites.net/';
//    var serviceBase = 'http://192.168.0.76/';
//var serviceBase = '//g5api.azurewebsites.net/';
//var serviceBase = '//gamyfidev-api.azurewebsites.net/';
var serviceBase = '//gamyfistage-api.azurewebsites.net/';



(function () {
    'use strict';

//        .module('app', ['ui.router', 'ngMessages', 'ngStorage', 'ngMockE2E', 'angular-jwt', 'angular-storage'])
    angular
            .module('app', ['ngRoute', 'ngMessages', 'ngStorage', 'ngResource', 'angular-jwt', 'angular-storage', 'ngKookies', 'LocalStorageModule', 'ngCookies', 'ngAnimate', 'ngImgCrop', 'angular-svg-round-progressbar'])
            .config(config)
            .run(run);

    function config($routeProvider, $httpProvider) {
//, $urlRouterProvider, jwtInterceptorProvider, 
        // default route
//        $urlRouterProvider.otherwise("/login");

//        $httpProvider.defaults.useXDomain = true;
//        delete $httpProvider.defaults.headers.common["X-Requested-With"];
//        $httpProvider.defaults.headers.common["Access-Control-Allow-Origin"] = "*";
//        $httpProvider.defaults.headers.common["Accept"] = "application/json, text/plain, */*";
//        $httpProvider.defaults.headers.common["content-type"] = "application/json";

//        $httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
//        $httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
//        $httpProvider.defaults.useXDomain = true;
//        delete $httpProvider.defaults.headers.common['X-Requested-With'];
        // app routes
        $routeProvider
//                .when('/home', {
//                    templateUrl: 'home/index.view.html',
//                    controller: 'Home.IndexController'
//                })
                .when('/signUp/:id', {
                    templateUrl: 'assets/partials/userRegistration.html',
                    controller: 'UserRegistraiton.IndexController'
                })
                .when('/signUp', {
                    templateUrl: 'assets/partials/userRegistration.html',
                    controller: 'UserRegistraiton.IndexController'
                })
                .when('/forgotPassword', {
                    templateUrl: 'passwordreset/forgotPassword.html',
                    controller: 'PasswordReset.IndexController'
                })
                .when('/login', {
                    templateUrl: 'login/index.view.html',
                    controller: 'Login.IndexController'
                })
                .when('/refresh', {
                    templateUrl: 'refreshToken/index.view.html',
                    controller: 'Refresh.IndexController'
                })
                .when('/resetPassword', {
                    templateUrl: 'passwordreset/resetPassword.html',
                    controller: 'PasswordReset.IndexController',
                })
                .when('/changePassword', {
                    templateUrl: 'passwordreset/changePassword.html',
                    controller: 'PasswordReset.IndexController'
                })
                .when('/playZone', {
                    templateUrl: 'playZone/index.view.html',
                    controller: 'PlayZone.IndexController'
                })
                .when('/sitngo', {
                    templateUrl: 'sitngo/index.view.html',
                    controller: 'SitNGo.IndexController'
                })
                .when('/sitngo/:zone/:subject/:flavor', {
                    templateUrl: 'sitngo/index.view.html',
                    controller: 'SitNGo.IndexController'
                })
                .when('/profile', {
                    templateUrl: 'userprofile/index.view.html',
                    controller: 'UserProfile.IndexController'
                })
                .when('/editprofile', {
                    templateUrl: 'userprofile/editProfile.html',
                    controller: 'UserProfile.IndexController'
                })
                .when('/activate', {
                    templateUrl: 'assets/partials/UserActivation.html',
                    controller: 'UserRegistraiton.IndexController'
                })
                .when('/registerExternal', {
                    templateUrl: 'assets/partials/userRegistration.html',
                    controller: 'UserRegistraiton.IndexController'
                })
                .when('/dashboard', {
                    templateUrl: 'dashboard/index.view.html',
                    controller: 'Dashboard.IndexController'
                })
                .when('/popular', {
                    templateUrl: 'popular/index.view.html',
                    controller: 'Popular.IndexController'
                })
                .when('/flavors', {
                    controller: 'Flavors.IndexController',
                    templateUrl: 'flavors/index.view.html'
                })
                .when('/flavors/:subject', {
                    controller: 'Flavors.IndexController',
                    templateUrl: 'flavors/index.view.html'
                })
                .when('/flavors/:subject/:flavor', {
                    controller: 'Flavors.IndexController',
                    templateUrl: 'flavors/index.view.html'
                })
                .when('/flavors/:subject/:flavor/:stake', {
                    controller: 'Flavors.IndexController',
                    templateUrl: 'flavors/index.view.html'
                })
                .when('/favourite', {
                    templateUrl: 'favourite/index.view.html',
                    controller: 'Favourite.IndexController'
                })
                .when('/favourite/:subject', {
                    templateUrl: 'favourite/index.view.html',
                    controller: 'Favourite.IndexController'
                })
                .when('/authComplete', {
                    templateUrl: 'login/authComplete.view.html',
                    controller: 'Login.IndexController'
                })
                .when('/wallet', {
                    templateUrl: 'wallet/index.view.html',
                    controller: 'Wallet.IndexController'
                })
                .otherwise({
                    redirectTo: '/login'
                });
    }


    function run($rootScope, $http, $location, $localStorage, localStorageService) {


        // keep user logged in after page refresh
        var lc = localStorageService.get('currentUser');
        console.log('LC lc lc', lc);
        if (lc !== undefined && lc !== null) {
            $http.defaults.headers.common.Authorization = 'Bearer ' + lc.access_token;
        }



        // redirect to login page if not logged in and trying to access a restricted page
        $rootScope.$on('$locationChangeStart', function (event, next, current) {

//            console.log("Location change", event, next, current);
            var publicPages = ['/login'];
            var restrictedPage = publicPages.indexOf($location.path()) === -1;
            if (restrictedPage && !$localStorage.currentUser) {
//                $location.path('/login');
            }
        });
    }



    angular.module('app').constant('ngAuthSettings', {
        apiServiceBaseUri: serviceBase,
        clientId: 'WebApp'
    });

    angular.module('app').config(function ($httpProvider) {
        $httpProvider.interceptors.push('authInterceptorService');
    });

    angular.module('app').run(['authService', function (authService) {
            authService.fillAuthData();
        }]);


    angular.module('app').run(function ($rootScope, $window, $cookies, $location, localStorageService) {
        $rootScope.$on("$locationChangeStart", function (event, next, current) {
            // handle route changes   
            $rootScope.urlChanged = $location.path();
            $rootScope.userCheckLogged = $cookies.get('currentUser');
//            if ($rootScope.urlChanged == "/login" || $rootScope.urlChanged == "/register") {
            if ($rootScope.userCheckLogged == undefined) {
                $rootScope.loggedInUserCheck = false;
                console.log("URL Changed on Redirect", $rootScope.urlChanged, $window.location.href);
                if ($rootScope.urlChanged != "/passwordreset" || $rootScope.urlChanged != "/registerExternal") {
//                    $window.location.href = "#/login";
                }

            } else {
                $rootScope.loggedInUserCheck = true;
            }
            console.log("Changed URL", event, next, current, "Online", $rootScope.online);

        });
        /* Checking the Internet Connection */
        $rootScope.online = navigator.onLine;
        $window.addEventListener("offline", function () {
            $rootScope.$apply(function () {
                $rootScope.online = false;
            });
        }, false);

        $window.addEventListener("online", function () {
            $rootScope.$apply(function () {
                $rootScope.online = true;
            });
        }, false);
    });
})();