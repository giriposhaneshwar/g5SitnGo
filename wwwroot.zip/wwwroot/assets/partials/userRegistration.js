(function () {
    'use strict';
    angular
            .module('app')
            .controller('UserRegistraiton.IndexController', Controller);
    function Controller($scope, $location, $window, $q, $http, $timeout, localStorageService, AuthenticationService, commonService, serviceCall) {


    }

})();
/*
 // Login Service call
 http://192.168.0.47/token
 */ 