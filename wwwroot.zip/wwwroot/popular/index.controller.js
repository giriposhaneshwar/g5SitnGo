(function () {
    'use strict';
    angular
            .module('app')
            .controller('Popular.IndexController', Controller);
    function Controller($scope, commonService, serviceCall, $localStorage) {

        var vm = this;
        var data = "";
        var popularGames;
        var trendingGames;
        var subjectsList;

        $scope.init = function () {
            $scope.playZones();
            $scope.getRecentGames();
            $scope.popularGames();
        }

        $scope.popularGames = function () {
            serviceCall.popularGamesService(function (response) {
                commonService.log("popular : " + JSON.stringify(response));
                var popularGames = parsePopular(response);
                $scope.popularGames = popularGames;
            });
        }
        function parsePopular(json) {
            //var json = JSON.parse(jsonStr);
            var errorCode = json["errorCode"];
            var results;
            var subjects = [];
            subjects.flavor = [];
            if (errorCode === 200) {
                results = json["result"];
                for (var i = 0; i < results.length; i++) {
                    subjects[i] = results[i]["subject"];
                    subjects[i].title = subjects[i]["title"];
                    subjects[i].imageURL = subjects[i]["imageURL"];
                    subjects.flavor[i] = results[i]["flavor"];
                    subjects.flavor[i].title = subjects.flavor[i]["title"]
                    subjects.flavor[i].imageURL = subjects.flavor[i]["imageURL"];
                    commonService.log(subjects[i].title, subjects.flavor[i].title);
                }
            }
            return subjects;
        }

        $scope.getRecentGames = function () {
            serviceCall.recentGamesService(function (response) {
                console.log("Recent data Original", response);
                getSubjects();
                $scope.recentGames = response.result;
                $scope.recentGames.isNewUser = false;
                console.log("Recent Data", JSON.stringify($scope.recentGames), $scope.subjects);
                if ($scope.recentGames.isNewUser) {
                    $scope.recentGames.recentActivites = $scope.subjects;
                }
            });
        }

        $scope.playZones = function () {
            if ($localStorage.playZones == undefined) {
                serviceCall.zoneDetailsService(function (response) {
                    //commonService.log("Playzone :" + response);
                    var result = response["result"];
                    var errorCode = response["errorCode"];
                    if (errorCode === 200) {
                        commonService.log("playzone error code => 200");
                        commonService.log("***************************");
                        $localStorage.playZones = result;
                    }
                    getSubjects();
                });
            }
        }

        function getSubjects() {
            var playZones = $localStorage.playZones;
            var subjectsList = playZones[0]["subjects"];
            var subjects = [];
            for (var i = 0; i < subjectsList.length; i++) {
                commonService.log("***************************** SubjectsList *******************");
                commonService.log(subjectsList[i]['title']);
                subjects[i] = subjectsList[i];
                commonService.log(subjects[i]);
            }
            $scope.subjects = subjectsList;
            $scope.isNewUser = true;
            for (var i = 0; i < subjects.length; i++) {
                commonService.log("***************************** Subjects *******************");
                commonService.log(subjects[i]);
            }

        }
    }

})();

