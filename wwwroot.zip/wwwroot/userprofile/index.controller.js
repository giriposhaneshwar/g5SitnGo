(function () {
    'use strict';
    angular
            .module('app')
            .controller('UserProfile.IndexController', Controller);

    function Controller($scope, $rootScope, $location, $window, $q, $http, $localStorage, $cookies, $timeout, localStorageService, AuthenticationService, commonService, serviceCall) {
        var vm = this;
        $rootScope.profileData = 1;
        $scope.loading = false;
        $scope.files = [];
        $scope.profile = {};
        $scope.maleGender = true;
        $scope.femaleGender = true;
        $scope.profileImage = '';
        $scope.panImage = '';
        $scope.myImage = '';
        $scope.myCroppedImage = '';
        $scope.profileData = $rootScope.profileData;
        $scope.myImage1 = '';
        $scope.myCroppedImage1 = '';
        $scope.files = [];
        $scope.CountryName = '';
        $scope.StateName = '';
        $scope.tempFileHolder = {};
        $scope.previousBtn = false;
        $scope.nextBtn = true;
        var slideindex;

        $scope.editProfileObject = {};
        $scope.CountryArray = [];
        $scope.StateArray = [];
        $scope.emailPattern = /^[a-z]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/;
        $scope.checkData = function () {
            if ($scope.profile.gender == (null || undefined) || $scope.profile.gender == '')
                ;
        }
        $scope.showProfile = function () {
            $scope.profileData = 2;
        }
        $scope.editProfile = function () {
            $scope.profileData = 3;
        }
        $scope.myProfile = function () {
            $scope.profileData = 1;
        }
        $scope.getCarouselIndex = function (dir) {
            slideindex = $('#profileCarousel .active').index();

            if ($scope.profile.gender == (null || undefined) || $scope.profile.gender == '' || $scope.profile.firstName == (null || undefined) || $scope.profile.firstName == '' || $scope.profile.lastName == (null || undefined) || $scope.profile.lastName == '' || $scope.profile.displayName == (null || undefined) || $scope.profile.displayName == '')
                alert("please fill the required fields");
            else {
                if (dir == 'r') {

                    slideindex = slideindex + 1;
                    $("#profileCarousel").carousel(slideindex);
                } else if (dir == 'l') {
                    slideindex = slideindex - 1;
                    $("#profileCarousel").carousel(slideindex);
                }

                if (slideindex == 0) {
                    $scope.previousBtn = false;
                    $scope.nextBtn = true;
                } else if (slideindex == 3) {
                    $scope.previousBtn = true;
                    $scope.nextBtn = false;
                } else {
                    $scope.previousBtn = true;
                    $scope.nextBtn = true;
                }
            }
        };


        $scope.handleFileSelect = function (evt) {

            var file = evt.currentTarget.files[0];
            console.log(evt.currentTarget.attributes['id'].value);
            $scope.uploadId = evt.currentTarget.attributes['id'].value;
            var reader = new FileReader();
            reader.onload = function (evt) {
                $scope.$apply(function ($scope) {
                    var obj = {};



                    if ($scope.uploadId == "profilePic") {
                        $scope.myImage = evt.target.result;
                        $scope.firstimage = true;
                        $scope.secondimage = false;
                    }
                    if ($scope.uploadId == "panPic") {
                        $scope.myImage1 = evt.target.result;
                        $scope.firstimage = false;
                        $scope.secondimage = true;
                    }
                });
            };


            reader.readAsDataURL(file);

            $("#filepop").modal({show: true, backdrop: 'static', keyboard: false});
        };
        //angular.element(document.querySelector('#fileInput')).on('change', handleFileSelect);
        // angular.element(document.querySelector('#fileInput1')).on('change', handleFileSelect);


        $scope.selectGender = function (id) {

            if (id == 0) {
                $scope.profile.gender = "male";
                $scope.maleGender = false;
                $scope.femaleGender = true;
            } else if (id == 1) {
                $scope.profile.gender = "female";
                $scope.maleGender = true;
                $scope.femaleGender = false;
            }
        }



        $scope.getStates = function () {


            serviceCall.getState($scope.profile.countryId, function (response) {

                $scope.StateArray = response.result;


                angular.forEach($scope.StateArray, function (state) {

                    if ($scope.profile.stateId != null && state.id == $scope.profile.stateId) {
                        $scope.StateName = state.name;


                    }
                });
            });
        };


        $scope.init = function () {
            //country list

            serviceCall.getCountry(function (response) {

                $scope.CountryArray = response.result;
                $scope.getProfileData();

            });
            $scope.profileImage = '';
            $scope.panImage = '';



            $('.progress_bar_3').gradientProgressBar({
                value: 0.81,
                size: 350,
                fill: {
                    gradient: ["red", "blue", "green"]
                }
            });

            //              $scope.locationData("./userprofile/locationData.json");
        };



        $scope.locationData = function (url) {
            $http.get(url).then(function (response) {
                commonService.log("Locaiton loded", response);
                $scope.locData = response.data;
                $scope.states = [];
                var sObj = {};
                var i;
                angular.forEach($scope.locData, function (a, b) {
                    var obj = {};
                    obj.state = a.state;
                    obj.sno = b;
                    sObj[a.state] = obj;
                    $scope.states = sObj;
                });
            }).catch(function (err) {
                commonService.log("Load Json Errror", err);
            });
        };
        $scope.uploadFile = function (name, file) {
            if (file) {
                $scope.editProfileObject[name] = file;
            }
            $scope.editProfileObject.data = $scope.profile;
        };

        $scope.updateProfileSubmit = function (evt) {
            evt.preventDefault();
            serviceCall.editProfileService($scope.editProfileObject, function (response) {
                commonService.log("Response on Edit Profile", response);

            });
        };

        $scope.getProfileData = function () {

            commonService.log("User Profile is ", $scope.userData);
            var tStamp = new Date();

            serviceCall.getProfileService(function (response) {
                commonService.log("Response from Profile", response);
                if (!response.isError) {
                    $scope.profile = response.result;

                    if ($scope.profile.countryId == (null || undefined)) {

                        $scope.profile.countryId = 101;
                    }
                    angular.forEach($scope.CountryArray, function (country) {
                        if (country.id == $scope.profile.countryId) {
                            $scope.CountryName = country.name;

                        }
                    });
                    $scope.getStates();
                    if (response.result.profileImageUrl != null) {

                        $scope.profileImage = response.result.profileImageUrl + "?v=" + tStamp.getTime();
                    }
                    if (response.result.panImageUrl != null) {
                        $scope.panImage = response.result.panImageUrl + "?v=" + tStamp.getTime();
                    }
                    if (response.result.gender != null) {

                        if (response.result.gender == 'male') {
                            $scope.maleGender = false;
                            $scope.femaleGender = true;
                        } else {
                            $scope.maleGender = true;
                            $scope.femaleGender = false;
                        }

                    }

                    $scope.profile.dateOfBirth = commonService.dateToLocal(response.result.dateOfBirth);
                    $('.form-control').on('focus blur', function (e) {
                        $(this).parents('.form-group').toggleClass('focused', (e.type == 'focus' || this.value.length > 0));

                    }).trigger('blur');

                }
            });

        };

        //an array of files selected
        $scope.files = [];
        $scope.fileUploadError = "";
        $scope.fileField = {};
        //listen for the file selected event
        $scope.$on("fileSelected", function (event, args) {
            $scope.$apply(function () {
                //add the file object to the scope's files collection
                var fileSize = (args.file.size / 1000).toFixed(2);
                if (fileSize > commonService.fileSize) {
                    $scope.fileField[args.name] = true;
                    $scope.fileUploadError = "File Size should not exceed 512Kb";
                } else {
                    $scope.fileField[args.name] = false;
                    //                    if($scope.files['name'])
                    angular.forEach($scope.files, function (a, b) {
                        commonService.log("Files Uploaded", a.name, a.name.length);
                    });
                    //                    $scope.files.push({"name": args.name, "file": args.file});
                }
            });
        });
        //the save method
        var fileLength = 0;
        var userData = localStorageService.get('userInfo');
        $scope.upload = function () {
            if ($scope.uploadId == "profilePic") {
                var obj = {};
                obj['name'] = $scope.uploadId;
                obj['file'] = $scope.myCroppedImage;
                $scope.profileImage = $scope.myCroppedImage;
            } else if ($scope.uploadId == "panPic") {
                var obj = {};
                obj['name'] = $scope.uploadId;
                obj['file'] = $scope.myCroppedImage1;
                $scope.panImage = $scope.myCroppedImage1;
            }
            if ($scope.tempFileHolder.hasOwnProperty($scope.uploadId)) {
                $scope.tempFileHolder[obj.name] = obj.file;
            } else {
                $scope.tempFileHolder[obj.name] = obj.file;
                fileLength++;
            }
            console.log($scope.tempFileHolder);
        }
        $scope.save = function () {



            $scope.profile.dateOfBirth = commonService.standardTimeFormat($scope.profile.dateOfBirth);
            var userInfo = localStorageService.get('userInfo');
            commonService.log("User Profile Before Submit:::::", $scope.profile, $scope.files);
            if ($scope.profile.dateOfBirth == "NaN-NaN-NaN") {
                commonService.log("User Profile Before Submit dateeeee:::::", $scope.profile, $scope.files);
                $scope.profile.dateOfBirth = commonService.standardTimeFormat(userInfo.dateOfBirth);
            }


            commonService.log("Upload Files ", $scope.profile, $scope.files);
            /* Http request with files   and without file   "application/x-www-form-urlencoded" */
            if (fileLength > 0) {

                $http({
                    method: 'POST',
                    url: serviceBase + "Api/Account/Profile",
                    headers: {'Content-Type': undefined},
                    transformRequest: function (data) {
                        console.log(data.files);

                        //                    data.model.dateOfBirth = commonService.dateToGlobal(data.model.dateOfBirth);
                        var formData = new FormData();
                        data.model = angular.toJson(data.model);
                        formData.append("model", data.model);
                        for (var i in $scope.tempFileHolder) {
                            formData.append(i, $scope.tempFileHolder[i]);
                        }
                        //                        for (var i = 0; i < length; i++) {
                        //                            console.log(data.files.length);
                        //
                        //                            //add each file to the form data and iteratively name them
                        //                            formData.append(data.files[i].name, data.files[i].file);
                        //
                        //                        }
                        commonService.log("Sending DATa - Files", data, formData);
                        return formData;
                    },
                    //Create an object that contains the model and files which will be transformed
                    // in the above transformRequest method
                    data: {model: $scope.profile, files: $scope.files}
                }).success(function (data, status, headers, config) {
                    commonService.log("Edit Profile REsponse 140:::", data);
                    if (!data.isError) {
                        $("#profileGreat").modal('show');
                        $scope.profileResponse = "Profile updated successfully!";
                        $scope.profileStatus = true;
                        $scope.profileMessageShow = true;
                        $scope.profile = data.result;
                        var userData = localStorageService.get('userInfo');
                        userData.userInfo = data.result;
                        localStorageService.set('userInfo', userData);

                        $scope.profile.dateOfBirth = commonService.dateToLocal(data.result.dateOfBirth);
                        $timeout(function () {
                            $("#profileGreat").modal('hide');
                            $('body').removeClass().removeAttr('style');
                            $('.modal-backdrop').remove();
                            $window.location.href = commonService.landingPage;
                            $scope.myImage = '';
                            $scope.myImage1 = '';
                            $scope.myCroppedImage = '';
                            $scope.myCroppedImage1 = '';
                            $scope.getProfileData();
                        }, 3000);
                    }
                }).error(function (data, status, headers, config) {
                    commonService.log("Edit Profile REsponse ERROR 150:::", data);
                    $scope.profileResponse = "Failed!";
                    $scope.profileStatus = false;
                    $scope.profileMessageShow = true;
                });
            } else {
                $http({
                    method: 'POST',
                    url: serviceBase + "Api/Account/Profile",
                    //                    headers: {'Content-Type': "application/json"},
                    data: $scope.profile
                }).success(function (data, status, headers, config) {
                    commonService.log("Edit Profile REsponse 140:::", data);
                    if (data.errorCode === 200) {
                        $("#profileGreat").modal('show');
                        $scope.profileResponse = "Profile updated successfully!";
                        $scope.profileStatus = true;
                        $scope.profileMessageShow = true;
                        $scope.profile = data.result;

                        userData.userInfo = data.result;
                        localStorageService.set('userInfo', userData);

                        $scope.profile.dateOfBirth = commonService.dateToLocal(data.result.dateOfBirth);

                        $timeout(function () {

                            $("#profileGreat").modal('hide');
                            $('body').removeClass().removeAttr('style');
                            $('.modal-backdrop').remove();
                            $window.location.href = commonService.landingPage;
                            $scope.myImage = '';
                            $scope.myImage1 = '';
                            $scope.myCroppedImage = '';
                            $scope.myCroppedImage1 = '';
                            $scope.getProfileData();
                        }, 3000);
                    }
                }).error(function (data, status, headers, config) {
                    commonService.log("Edit Profile REsponse ERROR 150:::", data);
                    $scope.profileResponse = data.message;
                    $scope.profileStatus = false;
                    $scope.profileMessageShow = true;
                });
            }
        };
        /* Enabling the Calender for Date Field */
        $("#dateOfBirth").datetimepicker({
            'pickTime': false,
            'format': 'MM-DD-YYYY'
        });
        //            'defaultDate': new Date(),

        // This is what you will bind the filter to
        $scope.filterText = '';
        // Creating Delay to check on keyup
        var tempFilterText = '',
                filterTextTimeout;
        $scope.$watch('password2', function (val) {
            if (filterTextTimeout)
                $timeout.cancel(filterTextTimeout);
            tempFilterText = val;
            filterTextTimeout = $timeout(function () {
                $scope.filterText = tempFilterText;
            }, 250); // delay 250 ms
        });
        /* Execute the method on page load*/
        //logout
        $scope.init();

    }


})();
/*
 // Login Service call
 http://192.168.0.47/token
 */
