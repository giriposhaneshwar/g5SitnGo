(function () {
    'use strict';
    angular
            .module('app')
            .controller('mainController', Controller);

    function Controller($scope, $rootScope, $location, commonService, $window, $q, $http, $timeout, AuthenticationService, serviceCall) {

        var vm = this;
        vm.showprofile = false;

        // console.log($window.innerWidth);
        $scope.handleClick = function (event) {
//            console.log(angular.element(document.getElementById('country')));
            var offsetwidth = angular.element(document.getElementById('profile')).prop('offsetWidth');
            var modelwidth = angular.element(document.getElementById('filepop')).prop('offsetWidth');
            var width = $window.innerWidth - offsetwidth;
//            console.log(modelwidth + " " + width + " " + event.pageX);
            if (offsetwidth != 0)
            {
                if (modelwidth < 1 && event.pageX != 0)
                {
                    if (event.pageX < width && vm.showprofile == true)
                    {
                        vm.showprofile = false;
                    }
                }
            }
        };
        vm.editProfile = function ()
        {
            $scope.udInfo = commonService.getLocalStorage('userInfo');
            var t = commonService.checkGamy5User($scope.udInfo);
            $rootScope.profileData = 1;
            if (!t) {
                $window.location.href = "#/signUp";
            } else {
                if (vm.showprofile == false)
                    vm.showprofile = true;
                else
                    vm.showprofile = false;
            }
            console.log(vm.showprofile);

        }
        vm.close = function ()
        {
            vm.showprofile = false;
        }
        vm.changePassword = function ()
        {

            vm.showprofile = false;
            $window.location.href = "#/changePassword";
        }
        vm.logoutUser = function () {
            vm.close();
            serviceCall.logoutUser(function (res)
            {
                console.log("Logging user out", res);
                if (res.status === "success") {

                    $timeout(function () {

                        $location.path("/login");
                    }, 3000);
                } else {
                    alert("Could no loggout");
                }
            });
        };


    }


}());