(function () {
    'use strict';
    angular
        .module('app')
        .controller('navigationController', Controller);

    function Controller($scope, $location, $rootScope, $window, $q, $http, $timeout, AuthenticationService, serviceCall) {

        $scope.navItems = [
            {item: "Home", link: "#/home"},
            {item: "Profile", link: "#/profile"},
            {item: "Dashboard", link: "#/dashboard "}
        ];


        $scope.$watch('urlChange', function (scope) {
            // do something here
            console.log("URL Changed", scope);
        }, true);



//        $scope.$watch(function (scope) {
//            return scope.urlChange
//        },
//            function (newValue, oldValue) {
//
//                console.log("LoggedInState Watch", newValue, oldValue);
//            }
//        );

    }


}());