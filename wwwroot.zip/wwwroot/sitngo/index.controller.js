(function () {
    'use strict';
    angular
            .module('app')
            .controller('SitNGo.IndexController', ["$scope", "$rootScope", "$http", "$interval", "$compile", "signalRService", "playGameService", "$timeout", "$window", "$localStorage", 'roundProgressService', 'localStorageService', '$routeParams',
                function ($scope, $rootScope, $http, $interval, $compile, signalRService, playGameService, $timeout, $window, $localStorage, roundProgressService, localStorageService, $routeParams, commonService, serviceCall) {
                    var vm = this;
                    vm.zoneID = $routeParams.zone;
                    vm.url = 'api/Join/' + vm.zoneID;
                    var signalRServiceHub = '';
                    var token = localStorageService.get('currentUser');
                    var config = {
                        headers: {
                            'Authorization': 'Bearer ' + token.access_token
                        }
                    };
//                    MathJax.Hub.Config({
//                        extensions: ["tex2jax.js"],
//                        jax: ["input/TeX", "output/HTML-CSS"],
//                        tex2jax: {inlineMath: [
//                                ["$", "$"],
//                                ["\\(", "\\)"]
//                            ]}
//                    });
//                    var QUEUE = MathJax.Hub.queue; // shorthand for the queue

                    playGameService.gameUserRequest(serviceBase + vm.url, config, function (response, state) {
                        console.log("Rssssss", response);
                        if (response.data.errorCode === 200) {
                            $rootScope.gameObj = response;
                            $localStorage.gamePlayerInfo = {player: response.data.result.playerId, gameTable: response.data.result.gameTableID}
                            playGameService.startGame($rootScope.gameObj);
                        } else {
                            $rootScope.errMessage = response.data.errorMessage;
                            //alert("error");
                            console.log("ERRROr ", response);
                        }
                    });
                    $scope.$watch('$root.gameObj', function (newVal, oldVal) {
                        // on root varialbel change trigger the method789
                        console.log("New Val", newVal);
                        if ($rootScope.gameObj !== undefined) {
                            $localStorage.playerData = newVal;
                        }
                    });
                    $scope.$watch('$root.errMessage', function (newVal, oldVal) {
                        // on root varialbel change trigger the method789
                        if (newVal !== undefined) {
                            alert(newVal);
                        }
                    });
                    $scope.$watch('$root.timerStartCount', function (newVal, oldVal) {
                        // on root varialbel change trigger the method789
                        if (newVal !== undefined) {
                            $scope.updateCounter = newVal;
                        }
                    });
                    $scope.getMasterScope = function () {
                        console.log("Master Scope", $rootScope.gameMessage);
                    }

                    $scope.arr = {};
                    $scope.answeredTime = {};
                    $scope.answeredQuestion = function (evt, data, index) {
                        evt.preventDefault();
                        alert("button#opt_" + data);
                        $("button#opt_" + data).addClass('active');
//                        angular.element(document.querySelector("opt_" + data)).addClass('active');
                        $scope.isAnsweredDone = true;
                        $scope.answered = data;
                        $scope.answeredTime['end'] = playGameService.startTimeRun();
                        console.log("Answered is ", data, $scope.answeredTime);
                        //alert("Data :" + JSON.stringify(data));
                        //alert("Answered Time :" + $scope.answeredTime);
                        playGameService.submitAnswered(data, $scope.answeredTime, function (zoneMsg) {
                            console.log("Submit Answer Response ; " + zoneMsg);
                        });
                    }
//                    $scope.attemptAnswerButton = false;
//                    $scope.attemptAnswer = function (evt, data, key) {
//                        //alert("id:" + evt.target.id);
//                        //alert("data :" + JSON.stringify(data));
//                        //alert("key" + key);
//                        if (!$scope.attemptAnswerButton) {
//                            $scope.attemptAnswerButton = true;
//                            $scope.attempted = key;
//                            $scope.answered = data;
//                            var selectedEle = angular.element("#opt_" + data);
//                            //alert("clicked Element :" + selectedEle);
//                            selectedEle.parent().children().addClass('notAttempt');
//                            selectedEle.removeClass('notAttempt').addClass('attempt');
//                            $scope.showResult = ($scope.answer === $scope.answered);
//                            $scope.setClass = "attempt";
//                        }
//                    }
                    $scope.displayCorrectAnswer = function (data) {
                        $scope.correctAnswer = data.AnswerId;
                        var selectedEle = angular.element(".answerBtn");
                        //alert("clicked Element :" + selectedEle);
                        angular.forEach(selectedEle, function (n, i) {
                            var ele = angular.element(n);
                            var btnValue = angular.element(n).attr("optval");
                            if ($scope.answered != $scope.correctAnswer && btnValue == $scope.answered) {
                                ele.addClass('wrongAns');
                            }
                            if (btnValue == $scope.correctAnswer) {
                                ele.addClass('correctAns');
                            }
                            //                            angular.element(n).addClass("classAddddddded");

                            console.log("Selected Data", i, n);
                        });
                    }


                    $scope.$watch('$root.gameMessage', function (newVal, oldVal) {
                        if (newVal !== undefined) {
                            //                                    alert(JSON.stringify(newVal));
                            switch (newVal.method) {
                                case "JoinPlayerToTable":
                                    alert("join player to table");
                                    console.log("Player Info", newVal.message);
                                    $scope.arr[newVal.method] = newVal.message;
                                    $scope.selfMessage = $scope.arr[newVal.method];
                                    $scope.methodType = newVal.method;
                                    break;
                                case "sendMessage":
                                    //                                        alert("sendMessage");
                                    $scope.arr[newVal.method] = newVal.message;
                                    $scope.questionMessage = $scope.arr["sendMessage"];
                                    $scope.methodType = newVal.method;
                                    break;
                                case "playerJoinMessage":
                                    //                                        alert("player join message");
                                    $scope.arr[newVal.method] = newVal.message;
                                    $scope.questionMessage = $scope.arr["playerJoinMessage"];
                                    $scope.methodType = newVal.method;
                                    break;
                                case "sendGameStart":
                                    //                                        alert("send game start");
                                    $scope.arr[newVal.method] = newVal.message;
//                                    var gamePlayerInfo = {};
//                                    gamePlayerInfo['gameId'] = newVal.message.GameId;
                                    //                                    gamePlayerInfo['GameTableId'] = newVal.message.GameTableId;
                                    //                                    gamePlayerInfo['gameId'] = newVal.message.GameId;
                                    //                                    commonService.storeDataService(gamePlayerInfo, "gamePlayerInfo");
                                    $rootScope.gameObj['GameId'] = newVal.message.GameId;
                                    $scope.questionMessage = $scope.arr["sendGameStart"];
                                    $scope.headerMessage = $scope.arr["sendGameStart"];
                                    $scope.max = $scope.arr["sendGameStart"]["TimeToServeQuestion"];
                                    $scope.current = playGameService.startTimeRun($scope.max);
                                    $scope.methodType = newVal.method;
                                    break;
                                case "StartGame":
                                    //                                        alert("start game");
                                    $scope.arr[newVal.method] = newVal.message;
                                    $scope.questionMessage = $scope.arr["StartGame"];
                                    $scope.max = $scope.arr["StartGame"]["TimeToServeQuestion"];
                                    $scope.current = playGameService.startTimeRun($scope.max);
                                    $scope.methodType = newVal.method;
                                    break;
                                case "sendQuestion":
                                    //                                        alert("send question");
                                    $scope.arr[newVal.method] = newVal.message;
                                    $scope.questionMessage = $scope.arr["sendQuestion"];
                                    addEventListener('load', load, true);
                                    var choices = $scope.questionMessage.Choices;
                                    $localStorage.choices = choices;
                                    $timeout(function () {
                                        load(choices);
                                    }, 2000);
                                    $scope.methodType = newVal.method;
                                    $scope.reAnimate = true;
                                    $scope.max = $scope.arr["sendQuestion"]["TimetoAnswer"];
                                    $scope.current = playGameService.startTimeRun($scope.max);
                                    $scope.answeredTime['start'] = playGameService.startTimeRun();
                                    //                                            alert($rootScope.timerStartCount);
                                    break;
                                case "sendAnswer":
                                    //                                    alert("send answer");
                                    $scope.arr[newVal.method] = newVal.message;
                                    console.log("Send Answer AT Controller", newVal.method, $scope.arr[newVal.method]);
                                    $scope.questionMessage = $scope.arr["sendAnswer"];
                                    $scope.methodType = newVal.method;
                                    $scope.questionMessage['Choices'] = $localStorage.choices;
                                    $scope.displayCorrectAnswer($scope.questionMessage);
                                    break;
                                case "sendGameResults":
                                    //                                        alert("send game results");
                                    $scope.arr[newVal.method] = newVal.message;
                                    $scope.questionMessage = $scope.arr["sendGameResults"];
                                    $scope.headerMessage = $scope.arr["sendGameResults"];
                                    $scope.selfMessage = $scope.arr["sendGameResults"];
                                    // isAnswered => 1 (hasAnswered); isAnswered => 3 (not Answered); isAnswered => 2 (answered incorrect, hasAnswered). Assumption
                                    // [{"GameTableId":7450,"GameId":1003,"userId":"49D77067-09B4-4F64-A50C-7036CF4CC6E1","DisplayName":null,"timetakeninseconds":26410,"Earned":712.5,"IsCorrectAnswer":true,"Rank":1,"IsAnswered":1},{"GameTableId":7450,"GameId":1003,"userId":"4C2C321D-2041-4312-B57D-2AECA5274D00","DisplayName":null,"timetakeninseconds":26410,"Earned":712.5,"IsCorrectAnswer":true,"Rank":1,"IsAnswered":1},{"GameTableId":7450,"GameId":1003,"userId":"bc9862f9-aef0-4daa-81af-8a72d6d4e0bb","DisplayName":null,"timetakeninseconds":30,"Earned":0,"IsCorrectAnswer":false,"Rank":null,"IsAnswered":3}]                                            

                                    console.log(JSON.stringify($scope.arr["sendGameResults"]));
                                    $scope.methodType = newVal.method;
                                    $scope.isAnsweredDone = false;
                                    break;
                                case "sendExitMessage":
                                    //                                        alert("send exit message");
                                    $scope.arr[newVal.method] = newVal.message;
                                    $scope.questionMessage = $scope.arr["sendExitMessage"];
                                    $scope.methodType = newVal.method;
                                    break;
                            }
                            console.log("ScopeUpdate si ++++++++++++++++++++++++", $scope.arr);
                        }
                    });
                    function load(choices) {
                        var choices = $localStorage.choices;
                        for (var i = 0; i < choices.length; i++) {
                            console.log(choices[i]["ChoiceId"]);
                            var eleId = "opt_" + choices[i]["ChoiceId"];
                            var answerChoice = document.getElementById(eleId);
                            answerChoice.innerHTML = choices[i]["Title"];
                            MathJax.Hub.Queue(["Typeset", MathJax.Hub, answerChoice]);
                        }
                    }

                    $scope.exitCurrentGame = function () {
                        var playerObj = ($localStorage.gamePlayerInfo !== undefined) ? $localStorage.gamePlayerInfo : $rootScope.gameObj.data.result.playerId;
                        playGameService.exitPlayer(playerObj.player, playerObj.gameTable, function (response) {
                            if (response.status == "success") {
                                alert("Player Exited");
                            } else {
                                alert("please try again later");
                            }
                        });
                    };
                    // Round Progress bar code

                    $scope.current = 0;
                    $scope.max = 0;
                    $scope.offset = 0;
                    $scope.timerCurrent = 0;
                    $scope.uploadCurrent = 0;
                    $scope.stroke = 6;
                    $scope.radius = 25;
                    $scope.isSemi = false;
                    $scope.rounded = false;
                    $scope.responsive = false;
                    $scope.clockwise = false;
                    $scope.currentColor = '#45ccce';
                    $scope.bgColor = '#eaeaea';
                    $scope.duration = 45000;
                    $scope.currentAnimation = 'easeOutCubic';
                    $scope.animationDelay = 0;
                    $scope.getCurrent = function () {
                        if ($scope.reAnimate) {
                            return 0;
                        }
                        return $scope.current;
                    }

                    $scope.increment = function (amount) {
                        $scope.current += (amount || 1);
                    };
                    $scope.decrement = function (amount) {
                        $scope.current -= (amount || 1);
                    };
                    $scope.animations = [];
                    angular.forEach(roundProgressService.animations, function (value, key) {
                        $scope.animations.push(key);
                    });
                    $scope.getStyle = function () {
                        var transform = ($scope.isSemi ? '' : 'translateY(-50%) ') + 'translateX(-50%)';
                        return {
                            'top': $scope.isSemi ? 'auto' : '50%',
                            'bottom': $scope.isSemi ? '5%' : 'auto',
                            'left': '50%',
                            'transform': transform,
                            '-moz-transform': transform,
                            '-webkit-transform': transform,
                            'font-size': $scope.radius / 2 + 'px'
                        };
                    };
                    $scope.getColor = function () {
                        return $scope.gradient ? 'url(#gradient)' : $scope.currentColor;
                    };
                    $scope.showPreciseCurrent = function (amount) {
                        $timeout(function () {
                            if (amount <= 0) {
                                $scope.preciseCurrent = $scope.current;
                            } else {
                                var math = $window.Math;
                                $scope.preciseCurrent = math.min(math.round(amount), $scope.max);
                            }
                            //alert($scope.preciseCurrent);
                        });
                    };
                    var getPadded = function (val) {
                        return val < 10 ? ('0' + val) : val;
                    };
                    $interval(function () {
                        var date = new Date();
                        var hours = date.getHours();
                        var minutes = date.getMinutes();
                        var seconds = date.getSeconds();
                        $scope.hours = hours;
                        $scope.minutes = minutes;
                        $scope.seconds = seconds;
                        $scope.time = getPadded(hours) + ':' + getPadded(minutes) + ':' + getPadded(seconds);
                    }, 1000);
                }
            ])
            .directive('opponentsData', function ($parse, $localStorage) {
                //console.warn("opponentsData");
                var directiveDefinitionObject = {
                    restrict: 'EA',
                    link: function (scope, el, attr) {
                        var exp = $parse(attr.opponentsData);
                        //alert("I am in directive..."); 
                        //console.warn("opponents directive");
                        scope.$watchCollection(exp, function (newVal, oldVal) {
                            //var playerCount = 5;
                            //alert(newVal);
                            if (newVal !== undefined) {
                                // ********************* Game Results ***********************
                                // isAnswered => 1 (hasAnswered); isAnswered => 3 (not Answered); isAnswered => 2 (answered incorrect, hasAnswered). Assumption
                                // [{"GameTableId":7450,"GameId":1003,"userId":"49D77067-09B4-4F64-A50C-7036CF4CC6E1","DisplayName":null,"timetakeninseconds":26410,"Earned":712.5,"IsCorrectAnswer":true,"Rank":1,"IsAnswered":1},{"GameTableId":7450,"GameId":1003,"userId":"4C2C321D-2041-4312-B57D-2AECA5274D00","DisplayName":null,"timetakeninseconds":26410,"Earned":712.5,"IsCorrectAnswer":true,"Rank":1,"IsAnswered":1},{"GameTableId":7450,"GameId":1003,"userId":"bc9862f9-aef0-4daa-81af-8a72d6d4e0bb","DisplayName":null,"timetakeninseconds":30,"Earned":0,"IsCorrectAnswer":false,"Rank":null,"IsAnswered":3}]                                            

                                newVal = (typeof newVal === "string") ? JSON.parse(newVal) : newVal;
                                //                                console.log("Oponents Data is ", typeof newVal, newVal);
                                // number of players includeing self in "Players" key
                                //alert(newVal);
                                if (newVal.hasOwnProperty('TimeToServeQuestion')) {
                                    var oponents = getOponents(newVal.Players);
                                    var oponentsWalletInfo = oponentWallet(oponents);
                                    scope.oponentsWalletInfo = oponentsWalletInfo;
                                    var players = getPlayerInfo(oponents);
                                    //alert(JSON.stringify(players));
                                    players['PoolAmount'] = newVal.PoolAmount;
                                    scope.players = players;
                                } else if (newVal[0].hasOwnProperty('Earned')) {
                                    // Game Results                                    
//                                    alert("newVal :" + JSON.stringify(newVal));
//                                    console.info("stage 4 is there");
                                    var players = getPlayerInfoForResults(newVal);
                                    var newPlayers = getPlayerInfo(players);
                                    //alert(JSON.stringify(players));
//                                    newPlayers['PoolAmount'] = newVal.PoolAmount;
                                    scope.players = newPlayers;
                                    console.log("Game Results ||||||||||||||", scope.players);
                                    alert("changed");
                                } else if (!newVal.hasOwnProperty('UserWallet')) {
                                    //var oponentWalletUpdate = updateOponentWallet(scope.oponentsWalletInfo, newVal);
                                }
                            }
                        });
                        function displayPlayerResults(data) {
                            console.log("Game Results are from Direction @@@@@@@@@@@@@@ \n", data);
                        }

                        function updateOponentWallet(playersInfo, data) {
                            if (data instanceof Array) {
                                // adding the vales on display results
                                var oponentWalletStorage = [];
                                angular.forEach(data, function (a, b) {
                                    angular.forEach(playersInfo, function (i, n) {
                                        if (a.UserId == i.UserId) {
                                            //                                            console.log("Oponent Storage", i, a);
                                            i.FreeCoins = parseFloat(i.FreeCoins) + parseFloat(a.Earned);
                                            oponentWalletStorage.push(i);
                                        }
                                    });
                                });
                                //                                console.log("Final Oponent Data", oponentWalletStorage);
                                $localStorage.oponentWalletStore = oponetWalletStorage;
                            }
                        }

                        function getOponents(playerData) {
                            //                            console.log(typeof playerData, playerData);
                            var oponentsArr = [];
                            for (var player in playerData) {
                                var playerInfo = playerData[player];
                                if (playerInfo.UserId != $localStorage.selfUserId) {
                                    oponentsArr.push(playerData[player]);
                                }
                            }
                            return oponentsArr;
                        }

                        function oponentWallet(oponents) {
                            console.log("Oponents are", oponents);
                            var oponentArr = [];
                            angular.forEach(oponents, function (a, b) {
                                oponentArr.push(a.UserWallet);
                            });
                            $localStorage.oponentWalletStore = oponentArr;
                            return oponentArr;
                        }

                        function getPlayerInfo(newVal) {

                            var maxPlayers = 5;
                            var playerCount = getPlayerCount(newVal);
                            var playerPosition = getPlayerPositions(playerCount);
                            var playersInfoArr = [];
                            var returnObj = {};
                            //                            alert(obj);

                            //                        {"playersInfo":[{"player":{"PlayerId":1586, "GameTableId":7449, "UserId":"3E26395F-632F-4339-A0C5-73D90FBDD6EA", "ProfileImage":null, "DisplayName":"Rahul", "Status":3, "UserWallet":{"FreeCoins":17000, "Amount":50000, "UserId":"3E26395F-632F-4339-A0C5-73D90FBDD6EA"}}, "playerPosition":{"left":240, "top":63, "width":50, "height":50, "seat":2}}, {"player":{"PlayerId":1587, "GameTableId":7449, "UserId":"42B77624-8227-4A7A-8869-AC10F7E33DF7", "ProfileImage":null, "DisplayName":"Amelie", "Status":3, "UserWallet":{"FreeCoins":17500, "Amount":50000, "UserId":"42B77624-8227-4A7A-8869-AC10F7E33DF7"}}, "playerPosition":{"left":480, "top":50, "width":50, "height":50, "seat":1}}]}

                            for (var i = 0; i < maxPlayers; i++) {
                                //alert("Player Info :" + JSON.stringify(newVal[i]));
                                var nObj = {};
                                nObj['player'] = newVal[i];
                                var j = i + 1;
                                nObj['class'] = (newVal[i] !== undefined) ? "{'col-xs-2':true,'player" + j + "':true}" : "{'col-xs-2':true,'noPlayer':true,'player" + j + "':true}";
                                nObj['playerPosition'] = playerPosition[i];
                                playersInfoArr.push(nObj);
                            }
                            returnObj['playersInfo'] = playersInfoArr;
                            return returnObj;
                        }

                        function getPlayerInfoForResults(newVal) {
                            // ********************* Game Results ***********************
                            // isAnswered => 1 (hasAnswered); isAnswered => 3 (not Answered); isAnswered => 2 (answered incorrect, hasAnswered). Assumption
                            // [{"GameTableId":7450,"GameId":1003,"userId":"49D77067-09B4-4F64-A50C-7036CF4CC6E1","DisplayName":null,"timetakeninseconds":26410,"Earned":712.5,"IsCorrectAnswer":true,"Rank":1,"IsAnswered":1},{"GameTableId":7450,"GameId":1003,"userId":"4C2C321D-2041-4312-B57D-2AECA5274D00","DisplayName":null,"timetakeninseconds":26410,"Earned":712.5,"IsCorrectAnswer":true,"Rank":1,"IsAnswered":1},{"GameTableId":7450,"GameId":1003,"userId":"bc9862f9-aef0-4daa-81af-8a72d6d4e0bb","DisplayName":null,"timetakeninseconds":30,"Earned":0,"IsCorrectAnswer":false,"Rank":null,"IsAnswered":3}]                                            

                            var maxPlayers = 5;
                            var playerCount = getPlayerCount(newVal);
                            var playerPosition = getPlayerPositions(playerCount);
                            var playersInfoArr = [];
                            var returnObj = {};
                            newVal = (typeof newVal == "string") ? JSON.parse(newVal) : newVal;
                            angular.forEach(newVal, function (n, i) {
                                if (n.IsCorrectAnswer) {
                                    n.playerStyle = 'correctPlayer';
                                } else {
                                    if (n.IsAnswered == 1) {
                                        n.playerStyle = 'inCorrectPlayer';
                                    } else if (n.IsAnswered == 2) {
                                        n.playerStyle = 'skippedPlayer';
                                    } else if (n.IsAnswered == 3) {
                                        n.playerStyle = 'skippedPlayer';
                                    }
                                }
                                if (n.userId != $localStorage.selfUserId) {
                                    playersInfoArr.push(n);
                                }
                            });
                            // newVal :[{"GameTableId":7449,"GameId":1023,"userId":"49D77067-09B4-4F64-A50C-7036CF4CC6E1","DisplayName":null,"timetakeninseconds":26121,"Earned":712.5,"IsCorrectAnswer":true,"Rank":1,"IsAnswered":1},{"GameTableId":7449,"GameId":1023,"userId":"4C2C321D-2041-4312-B57D-2AECA5274D00","DisplayName":null,"timetakeninseconds":26121,"Earned":712.5,"IsCorrectAnswer":true,"Rank":1,"IsAnswered":1},{"GameTableId":7449,"GameId":1023,"userId":"bc9862f9-aef0-4daa-81af-8a72d6d4e0bb","DisplayName":null,"timetakeninseconds":30,"Earned":0,"IsCorrectAnswer":false,"Rank":null,"IsAnswered":3}]                            
//                            var users = (typeof newVal == "string") ? JSON.parse(newVal) : newVal;
//                            var players = [];
//                            for (var i = 0; i < users.length; i++) {
//                                players[i].userId = users[i]["userId"];
                            //                                players[i].DisplayName = users[i]["DisplayName"];
                            //                                players[i].timeTakenInSeconds = users[i]["timetakeninseconds"];
                            //                                players[i].Earned = users[i]["Earned"];
                            //                                players[i].isCorrectAnswer = users[i]["IsCorrectAnswer"];
                            //                                players[i].Rank = users[i]["Rank"];
                            //                                players[i].isAnswered = users[i]["isAnswered"];
                            //                            }

                            //                        {"playersInfo":[{"player":{"PlayerId":1586, "GameTableId":7449, "UserId":"3E26395F-632F-4339-A0C5-73D90FBDD6EA", "ProfileImage":null, "DisplayName":"Rahul", "Status":3, "UserWallet":{"FreeCoins":17000, "Amount":50000, "UserId":"3E26395F-632F-4339-A0C5-73D90FBDD6EA"}}, "playerPosition":{"left":240, "top":63, "width":50, "height":50, "seat":2}}, {"player":{"PlayerId":1587, "GameTableId":7449, "UserId":"42B77624-8227-4A7A-8869-AC10F7E33DF7", "ProfileImage":null, "DisplayName":"Amelie", "Status":3, "UserWallet":{"FreeCoins":17500, "Amount":50000, "UserId":"42B77624-8227-4A7A-8869-AC10F7E33DF7"}}, "playerPosition":{"left":480, "top":50, "width":50, "height":50, "seat":1}}]}

//                            for (var i = 0; i < maxPlayers; i++) {
//                                var nObj = {};
//                                nObj['player'] = (players[i] !== undefined) ? newVal[i] : {"player": "noPlayer"};
//                                if (newVal[i]["IsCorrectAnswer"] === true) {
//                                    nObj['class'] = (newVal[i] !== undefined) ? "{'col-xs-2':true,'player'" + j + "':true, 'correctPlayer': true}" : "{'col-xs-2':true,'noPlayer':true,'player" + j + "':true}";
//                                } else if (newVal[i]["IsCorrectAnswer"] === false && newVal[i]["isAnswered"] === 2) {
//                                    nObj['class'] = (newVal[i] !== undefined) ? "{'col-xs-2':true,'player'" + j + "':true, 'inCorrectPlayer': true}" : "{'col-xs-2':true,'noPlayer':true,'player" + j + "':true}";
//                                } else if (newVal[i]["IsCorrectAnswer"] === false && newVal[i]["isAnswered"] === 3) {
//                                    nObj['class'] = (newVal[i] !== undefined) ? "{'col-xs-2':true,'player'" + j + "':true, 'skippedPlayer': true}" : "{'col-xs-2':true,'noPlayer':true,'player" + j + "':true}";
//                                } else {
//                                    nObj['class'] = (newVal[i] !== undefined) ? "{'col-xs-2':true,'player'" + j + "':true}" : "{'col-xs-2':true,'noPlayer':true,'player" + j + "':true}";
                            //                                }
                            //                                nObj['playerPosition'] = playerPosition[i];
                            //                                playersInfoArr.push(nObj);
                            //                            }
                            //                            playersInfoArr['event'] = "showResults";
                            //                            returnObj['playersInfo'] = playersInfoArr;

                            //                            alert("Players Object :" + JSON.stringify(returnObj));

                            return playersInfoArr;
                        }

                        function getPlayerCount(newVal) {
                            // if the arguments is stirng in future you can handle and converto to array

                            return newVal.length;
                        }

                        function getPlayerPositions(count) {
                            var positions = [{}];
                            positions = getPositions(count);
                            return positions;
                        }

                        function getPositions(count) {
                            switch (count) {
                                case 1:
                                    return [{"left": 480, "top": 50, "width": 50, "height": 50, "seat": 1}];
                                case 2:
                                    return [{"left": 240, "top": 63, "width": 50, "height": 50, "seat": 2},
                                        {"left": 480, "top": 50, "width": 50, "height": 50, "seat": 1}
                                    ];
                                case 3:
                                    return [{"left": 240, "top": 63, "width": 50, "height": 50, "seat": 2},
                                        {"left": 480, "top": 50, "width": 50, "height": 50, "seat": 1},
                                        {"left": 720, "top": 63, "width": 50, "height": 50, "seat": 3}
                                    ];
                                case 4:
                                    return [{"left": 0, "top": 110, "width": 50, "height": 50, "seat": 4},
                                        {"left": 240, "top": 63, "width": 50, "height": 50, "seat": 2},
                                        {"left": 480, "top": 50, "width": 50, "height": 50, "seat": 1},
                                        {"left": 720, "top": 63, "width": 50, "height": 50, "seat": 3}
                                    ];
                                case 5:
                                    return [{"left": 0, "top": 110, "width": 50, "height": 50, "seat": 4},
                                        {"left": 240, "top": 63, "width": 50, "height": 50, "seat": 2},
                                        {"left": 480, "top": 50, "width": 50, "height": 50, "seat": 1},
                                        {"left": 720, "top": 63, "width": 50, "height": 50, "seat": 3},
                                        {"left": 950, "top": 110, "width": 50, "height": 50, "seat": 5}
                                    ];
                            }
                        }
                    },
                    templateUrl: 'directives/opponents.html'
                }
                return directiveDefinitionObject;
            })
            .directive('questionData', function ($parse, $timeout, $localStorage, $window) {
                var directiveDefinitionObject = {
                    restrict: 'EA',
                    link: function (scope, el, attr) {
                        var exp = $parse(attr.questionData);
                        scope.$watchCollection(exp, function (newVal, oldVal) {
                            if (newVal !== undefined) {
                                var currentEvent = getCurrentEvent(newVal);
                                //alert("current Event :" + currentEvent);

                                scope.state = "";
                                scope.stateMessage = "";
                                //                                alert(typeof newVal);
                                console.log("Question at Directive is ::::::::::::::::\n", typeof newVal, newVal);
                                try {
                                    var newVal = (typeof newVal !== "string") ? JSON.parse(newVal) : newVal;
                                } catch (ex) {
                                    console.log("Exception :" + ex);
                                }
                                var displayObject = getDisplayObject(newVal, currentEvent);
                                console.log("Curretn Event", currentEvent);
                                if (currentEvent === "joinTable") {
                                    scope.questionMessage = displayObject;
                                } else if (currentEvent === "startGame") {                                     // displayObject has json object which needs to be parsed to the scope appropriately
                                    var startGameJSON = parseStartGame(displayObject);
                                    scope.time = startGameJSON.TimeToServeQuestion;
                                    scope.questionMessage = startGameJSON.Message;
                                    scope.PoolAmount = startGameJSON.PoolAmount;
                                    scope.PlayerAttributes = startGameJSON.Players;
                                    scope.state = currentEvent;
                                    scope.stateMessage = startGameJSON.Message;
                                } else if (currentEvent === "serveQuestion") {
                                    var questionobj = parseQuestion(displayObject);
                                    console.log(questionobj);
                                    scope.question = questionobj.question;
                                    scope.time = questionobj.timeToAnswer;
                                    var questionText = document.getElementById("questionText");
                                    questionText.innerHTML = questionobj.question;
                                    MathJax.Hub.Queue(["Typeset", MathJax.Hub, questionText]);
                                    console.log("questionText Element :" + questionText);
                                    console.log("Question Description Directive :" + questionobj.question);
                                    scope.answerChoices = displayObject['Choices'];
                                    var choices = displayObject['Choices'];
                                    console.log("Choices" + JSON.stringify(displayObject['Choices']));
                                    scope.Players = questionobj.Players;
                                    scope.state = currentEvent;
                                    scope.stateMessage = questionobj.question;
                                } else if (currentEvent === "serveAnswer") {
                                    var answerObj = parseAnswer(displayObject);
                                    scope.answer = answerObj.answer;
                                    scope.Player = answerObj.Players;
                                    scope.state = currentEvent;
                                    // alert("Answer Choices :" + scope.answerChoices);
                                    // alert("Answer :" + scope.answer);
                                    // alert("Answered :" + scope.answered);
                                    //                                    checkAnswerResult(scope.answerChoices, scope.answer, scope.answered);

                                    //                                    scope.questionMessage = answerObj.answer;

                                    console.log("Answer Message", answerObj, scope.questionMessage);
                                } else if (currentEvent === "showResults") {
                                    var resultsObj = parseResults(displayObject);
                                    scope.timetakeninseconds = resultsObj.timetakeninseconds;
                                    scope.isCorrect = resultsObj.isCorrect;
                                    scope.Earned = resultsObj.Earned;
                                    scope.displayName = resultsObj.displayName;
                                } else if (currentEvent === "resetGame") {
                                    var resultsObj = newVal; //message
                                    scope.questionMessage = newVal;
                                }

                            }
                        });
                        // [{"GameTableId":7450,"GameId":1003,"userId":"49D77067-09B4-4F64-A50C-7036CF4CC6E1","DisplayName":null,"timetakeninseconds":26410,"Earned":712.5,"IsCorrectAnswer":true,"Rank":1,"IsAnswered":1},{"GameTableId":7450,"GameId":1003,"userId":"4C2C321D-2041-4312-B57D-2AECA5274D00","DisplayName":null,"timetakeninseconds":26410,"Earned":712.5,"IsCorrectAnswer":true,"Rank":1,"IsAnswered":1},{"GameTableId":7450,"GameId":1003,"userId":"bc9862f9-aef0-4daa-81af-8a72d6d4e0bb","DisplayName":null,"timetakeninseconds":30,"Earned":0,"IsCorrectAnswer":false,"Rank":null,"IsAnswered":3}]                                            

                        function parseResults(json) {

                            console.log(results.length);
                            for (var i = 0; i < results.length; i++) {
                                results[i].displayName = "";
                                results[i].timetakeninseconds = "";
                                results[i].isCorrect = "";
                                results[i].Earned = "";
                                console.log(results[i]["DisplayName"] + i);
                                results[i].displayName = results[i]["DisplayName"];
                                results[i].timetakeninseconds = results[i]["timetakeninseconds"];
                                results[i].isCorrect = results[i]["isCorrectAnswer"];
                                results[i].Earned = results[i]["Earned"];
                                results[i].isAnswered = results[i]["isAnswered"];
                                results[i].Rank = results[i]["Rank"];
                                console.log(results[i].displayName, results[i].timetakeninseconds);
                            }

                            return results;
                        }


                        function displayResults(json) {
                            var results = {};
                            for (var i = 0; i < results.length; i++) {
                                results[i].displayName = "";
                                results[i].timetakeninseconds = "";
                                results[i].isCorrect = "";
                                results[i].Earned = "";
                                //                                // console.log(results[i]["DisplayName"] + i);
                                results[i].displayName = results[i]["DisplayName"];
                                results[i].timetakeninseconds = results[i]["timetakeninseconds"];
                                results[i].isCorrect = results[i]["isCorrectAnswer"];
                                results[i].Earned = results[i]["Earned"];
                                //                                // console.log(results[i].displayName, results[i].timetakeninseconds);
                            }

                            return results;
                        }



//                        scope.attemptAnswerButton = false;
//                        scope.attemptAnswer = function (evt, data, key) {
//                            alert("id:" + evt.target.id);
//                            alert("data :" + JSON.stringify(data));
//                            alert("key" + key);
//                            if (!scope.attemptAnswerButton) {
//                                scope.attemptAnswerButton = true;
                        //                                scope.attempted = key;
                        //                                scope.answered = data.ChoiceId;
                        //                                var selectedEle = angular.element("#id_" + key);
                        //                                alert("clicked Element :" + selectedEle);
                        //                                selectedEle.parent().children().addClass('notAttempt');
                        //                                selectedEle.removeClass('notAttempt').addClass('attempt');
                        //                                scope.showResult = (scope.answer === scope.answered);
                        //                                scope.setClass = "attempt";
                        //                            }
                        //                        }
                        // method for showing the write or wrong answer with color codes
                        function checkAnswerResult(choices, val, ans) {
                            var selectedEle = angular.element(".answerBtn");
                            //alert("selected Element :" + JSON.stringify(selectedEle));
                            angular.forEach(selectedEle, function (ele, indx) {
                                var choseAnswer = angular.element(ele).attr('optval');
                                //alert("choseAnswer :" + JSON.stringify(choseAnswer));                                 var choseIndex = angular.element(ele).attr('optpos');
                                //alert("choseIndex :" + JSON.stringify(choseIndex));                                 var element = angular.element(ele);
                                if (choseIndex == scope.attempted) {
                                    if (scope.answer == scope.answered) {                                         //alert("Adding Correct Class");
                                        element.addClass('currect');
                                    } else {                                         //alert("Adding wrong Class");
                                        element.addClass('wrong');
                                    }
                                } else {
                                    if (scope.answer == choseAnswer) {                                         //alert("Adding correct Class. Not attempted");
                                        element.addClass('currect');
                                    }
                                }
                            });
                        }

                        function parseAnswer(json) {                             //json = (typeof json === "Object") ? json : JSON.parse(json);
                            var answerObj = {};
                            var Players = [{}];
                            Players = json['Players'];
                            var Message = json['Message'];
                            for (var i = 0; i < Players.length; i++) {
                                Players[i].UserId = Players[i]["UserId"];
                                Players[i].Status = Players[i]["Status"];
                            }

                            answerObj.Message = Message;
                            answerObj.answer = json['AnswerId'];
                            answerObj.Players = Players;
                            return answerObj;
                        }

                        function parseQuestion(json) {                             //                            json = (typeof json === "Object") ? json : JSON.parse(json);
                            var question = [{}];
                            question.question = json["Description"];
                            question.timeToAnswer = json["TimetoAnswer"];
                            console.log("Parsing question => question : " + question.question);
                            question.answerChoices = [{}];
                            question.answerChoices = json["Choices"];
                            for (var i = 0; i < question.answerChoices.length; i++) {
                                question.answerChoices[i].Title = question.answerChoices[i]["Title"];
                                question.answerChoices[i].ChoiceId = question.answerChoices[i]["ChoiceId"];
                                // console.log(question.answerChoices[i].Title, question.answerChoices[i].ChoiceId)
                            }

                            question.Players = [{}];
                            question.Players = json["Players"];
                            for (var i = 0; i < question.Players.length; i++) {
                                question.Players[i].UserId = question.Players[i]["UserId"];
                                question.Players[i].Status = question.Players[i]["Status"];
                                // console.log(question.Players[i].UserId, question.Players[i].Status);
                            }

                            return question;
                        }

                        function parseStartGame(json) {
                            json = (typeof json == "string") ? JSON.parse(json) : json;
                            var startGameJSON = {};
                            startGameJSON.TimeToServeQuestion = json['TimeToServeQuestion'];
                            startGameJSON.PoolAmount = json['PoolAmount'];
                            startGameJSON.Message = json['Message'];
                            startGameJSON.Players = [{}];
                            startGameJSON.Players = json['Players'];
                            for (var i = 0; i < startGameJSON.Players.length; i++) {
                                startGameJSON.Players[i].UserId = startGameJSON.Players[i]["UserId"];
                                startGameJSON.Players[i].ProfileImage = startGameJSON.Players[i]["ProfileImage"];
                                startGameJSON.Players[i].displayName = startGameJSON.Players[i]["DisplayName"];
                                startGameJSON.Players[i].Status = startGameJSON.Players[i]["Status"];
                                startGameJSON.Players[i].FreeCoins = startGameJSON.Players[i]['UserWallet']['FreeCoins'];
                                startGameJSON.Players[i].PaidAmount = startGameJSON.Players[i]['UserWallet']['PaidAmount'];
                                startGameJSON.Players[i].EarnAmount = startGameJSON.Players[i]['UserWallet']['EarnAmount'];
                                // console.log(startGameJSON.Players[i].FreeCoins);
                            }
                            return startGameJSON;
                        }

                        function getCurrentEvent(newVal) {
                            //t($localStorage.currentEvent);                             
                            var obj = (typeof newVal === "string") ? JSON.parse(newVal) : newVal;
                            var currentEvent;
                            //                            alert(typeof obj.TimeToServeQuestion);                             if (obj !== undefined) {
                            console.log("getCurrentEvent Metod", typeof obj, obj);
                            if (obj.hasOwnProperty('UserWallet')) {
                                currentEvent = "joinTable";
                            } else if (obj.hasOwnProperty('TimeToServeQuestion')) {
                                currentEvent = "startGame";
                            } else if (obj.hasOwnProperty('QuestionId')) {
                                currentEvent = "serveQuestion";
                            } else if (obj.hasOwnProperty('AnswerId')) {
                                currentEvent = "serveAnswer";
                            } else if (obj instanceof Array) {
                                currentEvent = "gameResults";
                            }
                            return currentEvent
                        }

                        function isJson(jsonToCheck) {
                            var isJson = false;
                            var outPutValue = "";
                            var objectConstructor = {}.constructor;
                            if (jsonToCheck.constructor === objectConstructor) {
                                outPutValue = JSON.stringify(jsonToCheck);
                                try {
                                    JSON.parse(outPutValue);
                                    isJson = true;
                                } catch (err) {
                                    isJson = false;
                                }
                            }
                            return isJson;
                        }
                        function getDisplayObject(newVal, currentEvent) {
                            var json;
                            if (typeof newVal !== "Object")
                                json = (typeof newVal === "String") ? JSON.parse(newVal) : newVal;
                            if (currentEvent === "init") {
                                return newVal; // string message
                            } else if (currentEvent in ["startGame", "serveQuestion", "serveAnswer", "showResults"]) {
                                return json;
                            } else {
                                return newVal; // for resetGame
                            }
                        }
                    },
                    templateUrl: 'directives/questions.html'
                }
                return directiveDefinitionObject;
            })
            .directive('selfData', function ($parse, $localStorage) {
                var directiveDefinitionObject = {restrict: 'EA',
                    link: function (scope, el, attr) {
                        var exp = $parse(attr.selfData);
                        scope.$watchCollection(exp, function (newVal, oldVal) {
                            console.log("Self Data is ", typeof newVal, newVal);
                            var playersPositon = [{"left": 480, "top": 250, "width": 50, "height": 50}];
                            scope.selfPosition = playersPositon;
                            var wallet = getWallet(newVal);
                            scope.wallet = wallet;
                            // console.log("Wallet Balence", scope.wallet, newVal)

                            function displaySelfResult(newVal) {
                                var playersInfoArr = [];
                                var returnObj = {};
                                newVal = (typeof newVal == "string") ? JSON.parse(newVal) : newVal;
                                angular.forEach(newVal, function (n, i) {
                                    if (n.IsCorrectAnswer) {
                                        n.playerStyle = 'correctPlayer';
                                    } else {
                                        if (n.IsAnswered == 1) {
                                            n.playerStyle = 'inCorrectPlayer';
                                        } else if (n.IsAnswered == 2) {
                                            n.playerStyle = 'skippedPlayer';
                                        } else if (n.IsAnswered == 3) {
                                            n.playerStyle = 'skippedPlayer';
                                        }
                                    }
                                    if (n.userId == $localStorage.selfUserId) {
                                        playersInfoArr.push(n);
                                    }
                                });
                                alert(JSON.stringify(playersInfoArr));
                                return  playersInfoArr;
                            }
                            if (newVal.hasOwnProperty('UserWallet')) {
                                scope.selfPlayer = newVal;
                            } else {
                                var obj = displaySelfResult(newVal);
                                scope.selfPlayer = obj[0];
                            }

                            function getWallet(newVal) {
                                var obj = (typeof newVal === "string") ? JSON.parse(newVal) : newVal;
                                if (obj !== undefined && obj.UserWallet) {                                     // console.log("Wallet Chcek ", typeof obj, obj);
                                    var wallet = (obj.UserWallet !== undefined) ? obj.UserWallet.FreeCoins : 0;
                                    $localStorage.selfWallet = wallet;
                                    //                                    wallet = $localStorage.selfWallet;
                                    $localStorage.selfUserId = obj.UserId;
                                } else { // show results
                                    // console.log("user object on 4th request", obj);
                                    if (obj !== undefined) {
                                        for (var i = 0; i < obj.length; i++) {
                                            if (obj[i]['UserId'] === $localStorage.selfUserId) {
                                                var wallet = $localStorage.selfWallet;
                                                $localStorage.selfWallet = parseFloat(wallet) + parseFloat(obj[i].Earned);
                                                wallet = $localStorage.selfWallet;
                                            }
                                        }
                                    } else {
                                        var wallet = 0;
                                    }
                                }

                                return wallet;
                            }

                        })
                    },
                    templateUrl: 'directives/self.html'
                }
                return directiveDefinitionObject;
            })
            .directive('latex', function () {
                return {restrict: 'AE',
                    link: function (scope, element) {
                        var newDom = element.clone();
                        element.replaceWith(newDom);
                        var pre = "\\(", post = "\\)";
                        if (element[0].tagName === 'Div') {
                            pre = "\\[";
                            post = "\\]";
                        }
                        scope.$watch(function () {
                            return element.html();
                        }, function () {
                            console.log(element);
                            newDom.html(pre + element.html() + post);
                            MathJax.Hub.Typeset(newDom[0]);
                        });
                    }
                }
            });
})()
