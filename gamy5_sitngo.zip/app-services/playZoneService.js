angular.module('app').factory('playZoneService', ['$resource', 'ngAuthSettings', function ($resource, ngAuthSettings) {
            
            /*
            return {               

                getPlayZones: function () {
                    var serviceBase = ngAuthSettings.apiServiceBaseUri;
                     var token = 'TqrWE0pVG96beY-5go4Ga3NIxI4A1Qycnyh6j39xGxLQDWqWo64nD49f4fBZwmPG5FIJK-AXKmtYIVDRsAcVRc5B-qwoWUxyl5NwqZdf0UgC8AXU-2L9dPReKGYCP6TaAtX_tINtzTQvEnVh17r9P8-q93Ui3Uv1fpU6s39xg3x76Q8Xz_nQXhrTM7W1nE1HKlLS27fPDMEY9tqWjOOFHWz--st0mRuQewcMnh2U_fuwGAgk9W17fEZEITY10Zhag8C_H8_Txgw1X0cnwpdtABMzT83nFfBsCjKh2qG_ejfIgnuNl2EjNWhf46FGSB0ZF4zuluxdcN_BO88r82aD2P-7B7HWp-sdp472hG82oHM';
                   
                    return $resource(
                        serviceBase + 'api/PlayZone',
                        {},
                        {
                            "query": {
                                method: "GET", isArray: true,
                                headers: {
                                    'Authorization': 'Bearer ' + token
                                }
                            }
                        })
                }
            }
            */
        }]);